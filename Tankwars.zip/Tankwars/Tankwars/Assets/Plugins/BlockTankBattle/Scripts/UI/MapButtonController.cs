﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using System;
using UnityEngine.UI;

public class MapButtonController : MonoBehaviour, IPointerClickHandler,IPointerExitHandler,IPointerEnterHandler
{
    public Sprite starUnlockSprite;
    public Sprite tankUnlockSprite;

    private bool isUnlock;
    private int stage;

    private Animator anim;
    private GameObject pointer;
    private MapController mapController;
    private Text textStage;
    private Image image;

    void Awake()
    {
        mapController = GetComponentInParent<MapController>();
        image = GetComponent<Image>();
        anim = GetComponent<Animator>();

        pointer = transform.GetChild(3).gameObject;
        stage = int.Parse(gameObject.name);

        textStage = transform.GetChild(4).GetComponent<Text>();
        textStage.text = stage.ToString();
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        if(isUnlock)
        {
            mapController.ClickStage(stage);
        }
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        //  print(stage);
        if (isUnlock)
            mapController.ChangeSelectStage(stage);
    }

    public void OnPointerExit(PointerEventData eventData)
    {

    }

    //--METHOD CLICK TO CHOSE STAGE--//
    public void ClickStage()
    {
        anim.SetTrigger("click");
    }

    //--METHOD ACTIVE STAGE--//
    public void ActiveStage()
    {
        pointer.SetActive(true);
    }

    //--METHOD DEACTIVE STAGE WHEN STAGE NOT CHOSE--//
    public void DeactiveStage()
    {
        pointer.SetActive(false);
    }

    //--METHOD UNLOCK CALL INTIAL--//
    public void StageUnlock(int star)
    {
        for(int i = 0;i<star;i++)
            transform.GetChild(i).GetComponent<Image>().sprite = starUnlockSprite;


        image.sprite = tankUnlockSprite;

        transform.GetChild(4).gameObject.SetActive(true);                           // Active number stage
        transform.GetChild(6).gameObject.SetActive(false);                          // Deactive lock

        isUnlock = true;
    }

    //--METHOD UNLOCK NEW LEVEL--//
    public void UnlockNewStage(int star)
    {
        transform.GetChild(6).GetComponent<Animator>().enabled = true;
        StartCoroutine(WaitToActiveStage(star));
    }

    IEnumerator WaitToActiveStage(int star)
    {
        yield return new WaitForSeconds(1.5f);
        StageUnlock(star);
    }

    //--METHOD SET STAR--//
    public void SetStar()
    {

    }
}
