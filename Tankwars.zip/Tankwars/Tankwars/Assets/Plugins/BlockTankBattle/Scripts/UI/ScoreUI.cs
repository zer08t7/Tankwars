﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;

public class ScoreUI : MonoBehaviour {

    public Text scoreDisplay;
    public Text scoreAddText;

    public float speedDisplayText = 2.0f;
    public Color colorBonus;
    public Color colorMinus;

    private int currentScoreDisplay;
    private Queue<int> scoreAdds = new Queue<int>();
    private bool canDisplay;

    void Start()
    {
        StateManager.Instance.OnStageGameEnd += StopDisplayText;
    }

    //--INTIAL METHOD--//
    public void Inital(int score)
    {
        scoreAdds.Clear();
        canDisplay = true;
        scoreAddText.color = new Color(1, 1, 1, 0);
        currentScoreDisplay = score;
        scoreDisplay.text = currentScoreDisplay.ToString();
    }

    //--PUBLIC METHOD--//
    public void AddSccore(int score)
    {
        scoreAdds.Enqueue(score);
    }

    void Update()
    {
        if (scoreAdds.Count > 0 && canDisplay)
            StartCoroutine(AppearScoreAdd(scoreAdds.Dequeue()));
    }

    //--METHOD DISPLAY UI--//
    IEnumerator AppearScoreAdd(int score)
    {
        canDisplay = false;

        Color colorUse = (score > 0) ? colorBonus : colorMinus;

        scoreAddText.text = (score > 0) ? ("+" + score.ToString()) : (score.ToString());
        scoreAddText.color = new Color(colorUse.r, colorUse.b, colorUse.g, 0);

        while (scoreAddText.color.a < 0.98f)
        {
            scoreAddText.color = new Color(colorUse.r, colorUse.g, colorUse.b, Mathf.MoveTowards(scoreAddText.color.a, 1, Time.deltaTime * speedDisplayText));
            yield return null;
        }

        int scoreWillReach = currentScoreDisplay + score;

        while (currentScoreDisplay != scoreWillReach)
        {
            currentScoreDisplay += ((int)Mathf.Sign(score));

            scoreDisplay.text = currentScoreDisplay.ToString();
            yield return null;
        }

        while (scoreAddText.color.a > 0.02f)
        {
            scoreAddText.color = new Color(colorUse.r, colorUse.g, colorUse.b, Mathf.MoveTowards(scoreAddText.color.a, 0, Time.deltaTime * speedDisplayText));
            yield return null;
        }

        scoreAddText.color = new Color(colorUse.r, colorUse.g, colorUse.b, 0);


        canDisplay = true;
    }

    void StopDisplayText()
    {
        canDisplay = false;
    }
}
