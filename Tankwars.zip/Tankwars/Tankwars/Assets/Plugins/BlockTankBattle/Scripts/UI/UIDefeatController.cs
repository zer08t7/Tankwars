﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class UIDefeatController : MonoBehaviour {

    public Text scoreDisplay;
    public Text bestScoreDisplay;

    private PersistentDataGameController persistentData;

    void Awake()
    {
        persistentData = FindObjectOfType<PersistentDataGameController>();
    }

    void OnEnable()
    {
        DisplayValueGameOver();
    }

    void DisplayValueGameOver()
    {
        scoreDisplay.text = persistentData.currentScore.ToString();
        bestScoreDisplay.text = persistentData.GetBestScore().ToString();
    }
}
