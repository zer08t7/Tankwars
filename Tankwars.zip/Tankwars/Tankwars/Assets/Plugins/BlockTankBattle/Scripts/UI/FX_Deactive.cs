﻿using UnityEngine;
using System.Collections;

public class FX_Deactive : MonoBehaviour
{

    public float timeDeactive = 2.0f;
    public bool isFollow = false;
    public bool isLiveAllTime = false;

    private float lastTime;
    private ParticleSystem particle;
    private bool free;

    void Awake()
    {
        particle = GetComponent<ParticleSystem>();
    }

    void OnEnable()
    {
        if (free)
        {
            transform.SetParent(transform);
            SmartPool.Despawn(this.gameObject);
            free = false;
        }
        else
        {
            if (!particle.isPlaying)
                particle.Play();
            StartCoroutine(StartDeactive());
        }
    }

    IEnumerator StartDeactive()
    {
        yield return new WaitForSeconds(0.1f);
        free = true;

        if (!isLiveAllTime)
            yield return new WaitForSeconds(timeDeactive);
        else
            yield return new WaitForSeconds(float.MaxValue);

        free = false;

        if (isFollow)
            transform.SetParent(transform);

        SmartPool.Despawn(this.gameObject);
    }
}
