﻿using UnityEngine;
using System.Collections;

public class UIBackgroundController : MonoBehaviour {

    //public float speed = 0.01f;

    private Transform[] lineBackground;
    private SpriteRenderer sprRender;

    private bool canFill = true;

    void Awake()
    {
        lineBackground = new Transform[transform.childCount];
        sprRender = GetComponent<SpriteRenderer>();

        for(int i=0;i<transform.childCount;i++)
            lineBackground[i] = transform.GetChild(i).transform;

        foreach (Transform line in lineBackground)
        {
            for(int i=0;i<line.childCount;i++)
            {
                line.GetChild(i).gameObject.SetActive(false);
            }
        }
    }

    #region Public method

    //--METHOD CALL OUTSIDE TO ACTIVE--//
    public void ActiveScreenUI()
    {
        if (canFill)
        {
            StartCoroutine(Active());
            StartCoroutine(FillBackground());
        }
    }

    //--METHOD CALL OUTSIDE TO DEACTIVE--//
    public void DeactiveSCreenUI()
    {
        if(!canFill)
        {
            StartCoroutine(Deactive());
            StartCoroutine(UnFillBackground());
        }
    }

    #endregion

    //--METHOD FILL BACKGROUND UI--//
    IEnumerator FillBackground()
    {
        while(sprRender.color.a < 0.99f)
        {
            sprRender.color = new Color(sprRender.color.r, sprRender.color.b, sprRender.color.g, Mathf.MoveTowards(sprRender.color.a, 1, Time.deltaTime * 3.5f));
            yield return null;
        }

        sprRender.color = new Color(1, 1, 1, 1);
    }

    //--METHOD UNFILL BACKGROUND UI--//
    IEnumerator UnFillBackground()
    {
        while (sprRender.color.a > 0.01f)
        {
            sprRender.color = new Color(1, 1, 1, Mathf.MoveTowards(sprRender.color.a, 0, Time.deltaTime * 2));
            yield return null;
        }

        sprRender.color = new Color(1, 1, 1, 0);
    }

    //--MATHOD CALL ACTIVE FILL BRICK BACKGROUND--//
    IEnumerator Active()
    {
        for (int i = 0; i < lineBackground.Length/2; i++)
        {
            StartCoroutine(ActiveBackgroundLeftBottom(i));
            StartCoroutine(ActiveBackgroundRightBottom(i));
            StartCoroutine(ActiveBackgroundLeftBottom(lineBackground.Length - i - 1));
            StartCoroutine(ActiveBackgroundRightBottom(lineBackground.Length - i - 1));
            yield return null;
        }
    }

    IEnumerator ActiveBackgroundLeftBottom(int index)
    {
        for(int i=0;i<(lineBackground[index].transform.childCount-1)/2+1;i++)
        {
            lineBackground[index].GetChild(i).gameObject.SetActive(true);
            yield return null;
        }

        // Check finish
        if(index == lineBackground.Length / 2-1)
        {
            canFill = false;
            EventManager.Instance.PostNotification(EVENT_TYPE.SCREEN_UI_ACTIVE_FNISH, this);
        }
    }

    IEnumerator ActiveBackgroundRightBottom(int index)
    {
        for (int i = lineBackground[index].transform.childCount - 1; i > (lineBackground[index].transform.childCount - 1) / 2; i--)
        {
            lineBackground[index].GetChild(i).gameObject.SetActive(true);
            yield return null;
        }
    }

    //--METHOD UNFILL BACKGROUND BRICK--//
    IEnumerator Deactive()
    {
        for (int i = lineBackground.Length / 2 - 1; i >= 0; i--)
        {
            StartCoroutine(DeactiveBackgroundLeftBottom(i));
            StartCoroutine(DeativeBackgroundRightBottom(i));
            StartCoroutine(DeactiveBackgroundLeftBottom(lineBackground.Length - i - 1));
            StartCoroutine(DeativeBackgroundRightBottom(lineBackground.Length - i - 1));
            yield return null;
        }
    }

    IEnumerator DeactiveBackgroundLeftBottom(int index)
    {
        for (int i = (lineBackground[index].transform.childCount - 1) / 2; i >=0; i--)
        {
            lineBackground[index].GetChild(i).gameObject.SetActive(false);
            yield return null;
        }

        // Check finish
        if (index == 0)
        {
            canFill = true;
            EventManager.Instance.PostNotification(EVENT_TYPE.SCREEN_UI_DEACTIVE_FINISH, this);
        }
    }

    IEnumerator DeativeBackgroundRightBottom(int index)
    {
        for (int i = (lineBackground[index].transform.childCount - 1) / 2; i < lineBackground[index].transform.childCount; i++)
        {
            lineBackground[index].GetChild(i).gameObject.SetActive(false);
            yield return null;
        }
    }

    //void Update()
    //{
    //    if (Input.GetKeyDown(KeyCode.T))
    //    {
    //        StartCoroutine(Deactive());
    //        StartCoroutine(UnFillBackground());
    //    }

    //    if (Input.GetKeyDown(KeyCode.U))
    //    {
    //        StartCoroutine(Active());
    //        StartCoroutine(FillBackground());
    //    }
    //}

}
