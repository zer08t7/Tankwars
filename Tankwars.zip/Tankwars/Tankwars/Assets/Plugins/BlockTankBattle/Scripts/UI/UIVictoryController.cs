﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class UIVictoryController : MonoBehaviour {

    public Image starSprite01;
    public Image starSprite02;
    public Image starSprite03;

    public Text scoreDisplay;
    public Text timeDisplay;

    public Sprite spriteStarUnlock;
    public Sprite spriteStarLock;

    private PersistentDataGameController persistentData;
    void Awake()
    {
        persistentData = FindObjectOfType<PersistentDataGameController>();
    }

    void OnEnable()
    {
        DisplayValueGameEnd();    
    }

    //--METHOD DISPLAY--//
    void DisplayValueGameEnd()
    {
        timeDisplay.text = persistentData.currentTimeString;
        scoreDisplay.text = persistentData.currentScore.ToString();

        int star = persistentData.currentStar;

        starSprite03.sprite = (star == 3) ? spriteStarUnlock : spriteStarLock;
        starSprite02.sprite = (star >= 2) ? spriteStarUnlock : spriteStarLock;
        starSprite01.sprite = spriteStarUnlock;

    }
}
