﻿using UnityEngine;
using System.Collections;
using System;
using UnityEngine.UI;

public class UIManager : MonoBehaviour, IListener
{
    public GameObject UIHome;
    public GameObject UIMap;
    public GameObject UIGamePlay;
    public GameObject UIJoytick;
    public GameObject UIShot;
    public GameObject UIPause;
    public GameObject UIDefeat;
    public GameObject UIVictory;
    public GameObject UITutorial;
    public Text textGuide;

    public MapController stageController;

    public Text stageText;

    public AudioSource audioSourceUI;
    public AudioSource audioSourceButtons;

    public AudioClip soundfx_buttonClick01;
    public AudioClip soundfx_buttonClick02;
    public AudioClip soundfx_winGame;
    public AudioClip soundfx_gameover;

    private UIBackgroundController uiBackground;
    private GameController gameController;
    private PersistentDataGameController persisData;

    private Animator animUI;
    private bool isBackHome;
    private float currentTimeScale;

    void Awake()
    {
        animUI = GetComponent<Animator>();
        uiBackground = FindObjectOfType<UIBackgroundController>();
        gameController = FindObjectOfType<GameController>();
        persisData = FindObjectOfType<PersistentDataGameController>();

        StateManager.Instance.OnStateGameHome += HomeUIActive;
        StateManager.Instance.OnStateGameStart += GetStageUI;
    }

    void Start()
    {
        EventManager.Instance.AddListener(EVENT_TYPE.SCREEN_UI_DEACTIVE_FINISH, this);
        EventManager.Instance.AddListener(EVENT_TYPE.SCREEN_UI_ACTIVE_FNISH, this);
    }

    #region Delegate function
    void HomeUIActive()
    {
        UIHome.SetActive(true);
        animUI.SetTrigger("home");
    }

    void GetStageUI()
    {
        if (GameController.currentLevel < 10)
            stageText.text = "Stage 0" + GameController.currentLevel;
        else
            stageText.text = "Stage " + GameController.currentLevel;
    }
    #endregion

    #region Public Function

    public void LoadToStage(int stage)
    {
        SoundManager.Instance.PlayBackgroundMusic();
        animUI.SetTrigger("loadStage");
        UIHome.SetActive(false);
        StartCoroutine(StartLevel(stage));
        
    }

    public void PlaySoundButtonClick()
    {
        SoundManager.Instance.PlaySound(audioSourceButtons, soundfx_buttonClick02);
    }

    #region UI Tutorial
    public void ActiveTutorial(string textGuide)
    {
        animUI.SetTrigger("tutorial");
        UITutorial.SetActive(true);
        UIJoytick.SetActive(false);
        UIShot.SetActive(false);
        this.textGuide.text = textGuide;
    }

    public void BackGamePlayFromTutorial()
    {
        UITutorial.SetActive(false);
        UIGamePlay.SetActive(true);
        UIJoytick.SetActive(true);
        UIShot.SetActive(true);
    }
    public void DeactiveTutorial()
    {
        UIGamePlay.SetActive(false);
        animUI.SetTrigger("gameplay");
    }
    #endregion

    public void Pause()
    {
        currentTimeScale = Time.timeScale;
        Time.timeScale = 0.0f;

        UIPause.SetActive(true);
        animUI.SetTrigger("pause");

        SoundManager.Instance.PlaySound(audioSourceButtons, soundfx_buttonClick01);
    }

    public void Resume()
    {
        Time.timeScale = currentTimeScale;

        animUI.SetTrigger("gameplay");
        StartCoroutine(WaitToDeactiveObj(UIPause, 1.5f));

        SoundManager.Instance.PlaySound(audioSourceButtons, soundfx_buttonClick01);
    }

    public void BackHomeFromPause()
    {
        SoundManager.Instance.StopPlayBackgroundMusic();

        Time.timeScale = 1.0f;

        StateManager.Instance.SetStateGame(GAME_STATE.GameOver);
        uiBackground.ActiveScreenUI();

        UIPause.SetActive(false);
        UIGamePlay.SetActive(false);
        UIJoytick.SetActive(false);
        UIShot.SetActive(false);

        isBackHome = true;

        SoundManager.Instance.PlaySound(audioSourceButtons, soundfx_buttonClick01);
    }

    //--CALL WHEN GAME OVER--//
    public void DefeatUIActive()
    {
        SoundManager.Instance.StopPlayBackgroundMusic();

        // set state gameover
        StateManager.Instance.SetStateGame(GAME_STATE.GameOver);

        uiBackground.ActiveScreenUI();

        UIGamePlay.SetActive(false);
        UIJoytick.SetActive(false);
        UIShot.SetActive(false);
    }

    //--CALL WHEN GAME END (VICTORY)--//
    public void VictoryUIActive()
    {

        SoundManager.Instance.StopPlayBackgroundMusic();

        // set stage end game
        StateManager.Instance.SetStateGame(GAME_STATE.GameEnd);

        uiBackground.ActiveScreenUI();

        UIGamePlay.SetActive(false);
        UIJoytick.SetActive(false);
        UIShot.SetActive(false);

        // Save stage and unlock
        persisData.SaveStageStatus(GameController.currentLevel, false);
        persisData.SaveStageStatus(GameController.currentLevel + 1, true);
    }

    //--CALL GO TOP SELECT STAGES--//
    public void GoToMap()
    {
        SoundManager.Instance.StopPlayBackgroundMusic();
        UIMap.SetActive(true);
        animUI.SetTrigger("map");
        StartCoroutine(CheckStage());

        SoundManager.Instance.PlaySound(audioSourceButtons, soundfx_buttonClick02);
    }

    IEnumerator CheckStage()
    {
        yield return new WaitForSeconds(0.5f);
        stageController.CheckUnlock();
        // print("check unlock!");
    }

    //--CALL REPLAY--//
    public void Replay()
    {
        UIDefeat.SetActive(false);
        uiBackground.DeactiveSCreenUI();
        gameController.RestartLevel();

        SoundManager.Instance.PlaySound(audioSourceButtons, soundfx_buttonClick01);
    }

    //-- USE FOR BUTTON UI GAMEOVER AND UI VICTORY--//
    public void ActiveHome()
    {
        gameController.ResetDataWhenPlayerSkipLevel();
        UIHome.SetActive(true);

        UIVictory.SetActive(false);
        UIDefeat.SetActive(false);

        animUI.SetTrigger("home");

        SoundManager.Instance.PlaySound(audioSourceButtons, soundfx_buttonClick01);
    }

    //--METHOD CALL NEXT LEVEL--//
    public void NextLevel()
    {
        UIVictory.SetActive(false);
        uiBackground.DeactiveSCreenUI();
        gameController.LoadLevel(GameController.currentLevel + 1);

        SoundManager.Instance.PlaySound(audioSourceButtons, soundfx_buttonClick01);
    }

    #endregion
    IEnumerator WaitToDeactiveObj(GameObject obj, float time)
    {
        yield return new WaitForSeconds(time);
        obj.SetActive(false);
    }

    IEnumerator WaitToActiveObj(GameObject obj, float time)
    {
        yield return new WaitForSeconds(time);
        obj.SetActive(true);
    }

    IEnumerator StartLevel(int stage)
    {
        yield return new WaitForSeconds(1.5f);
        UIMap.SetActive(false);
        animUI.SetTrigger("idle");
        uiBackground.DeactiveSCreenUI();
        gameController.LoadLevel(stage);
        //_text.text = "load map";
    }

    public void OnEvent(EVENT_TYPE Event_Type, Component Sender, object Param = null)
    {
        if (Event_Type == EVENT_TYPE.SCREEN_UI_DEACTIVE_FINISH)
        {
            UIGamePlay.SetActive(true);
            UIJoytick.SetActive(true);
            UIShot.SetActive(true);
            animUI.SetTrigger("gameplay");

            SoundManager.Instance.PlayBackgroundMusic();
        }
        else if (Event_Type == EVENT_TYPE.SCREEN_UI_ACTIVE_FNISH)
        {
            if (isBackHome)
            {
                gameController.ResetDataWhenPlayerSkipLevel();
                StateManager.Instance.SetStateGame(GAME_STATE.Home);
                isBackHome = false;
            }
            else if (StateManager.Instance.gameState == GAME_STATE.GameOver)
            {
                UIDefeat.SetActive(true);
                animUI.SetTrigger("defeat");
            }
            else if (StateManager.Instance.gameState == GAME_STATE.GameEnd)
            {
                UIVictory.SetActive(true);
                animUI.SetTrigger("victory");
            }
        }
    }

    public void PlaySoundWinGame()
    {
        SoundManager.Instance.PlaySound(audioSourceUI, soundfx_winGame);
    }

    public void PlaySoundGameOver()
    {
        SoundManager.Instance.PlaySound(audioSourceUI, soundfx_gameover);
    }
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Escape))
        {

            if (StateManager.Instance.gameState == GAME_STATE.GameStart && !UIPause.activeSelf)
                Pause();
            else if (StateManager.Instance.gameState == GAME_STATE.GameEnd || StateManager.Instance.gameState == GAME_STATE.GameOver)
            {
                if(UIDefeat.activeSelf || UIVictory.activeSelf)
                    ActiveHome();
            }
            else
                Application.Quit();
            
        }
    }

}
