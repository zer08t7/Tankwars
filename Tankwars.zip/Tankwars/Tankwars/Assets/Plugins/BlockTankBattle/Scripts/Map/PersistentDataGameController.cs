﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public struct StageData
{
    public string name;
    public int numberStar;
}

public class PersistentDataGameController : MonoBehaviour {

    #region Property

    public int currentScore
    {
        get { return _currentScore; }
        set {
            scoreUi.AddSccore(value - _currentScore);
            _currentScore = value;
        }
    }

    public int currentStar { get; private set; }
    public string currentTimeString { get; private set; }

    #endregion

    [SerializeField]
    public List<int> stageStarList = new List<int>();                                  // List stage unlock and have star

    public int limitStage { get; private set; }

    public ScoreUI scoreUi;
    public TimeGameController timeUI;

    // Time to caculate star
    public float timeFor3Star = 120;
    public float timeFor2Star = 180;

    private int _currentScore = 0;
    private int bestScore = 0;

    void Awake()
    {
        CheckStageStatus();

        limitStage = FindObjectOfType<MapDataController>().textAssets.Count;
    }

    void Start()
    {
        StateManager.Instance.OnStateGameStart += InitalUIValue;
    }

    public void ResetScore()
    {
        currentScore = 0;
    }

    public void AddScore(int value)
    {
        scoreUi.AddSccore(value);
        _currentScore += value;
    }

    //--METHOD SAVE STAGE STATUS--//
    public void SaveStageStatus(int stage, bool isUnlock = false)
    {
        if (stage == limitStage)
        {
            Debug.Log("Stage limited!");
            return;
        }

        currentTimeString = timeUI.GetTimeString();

        int _currentStar;

        if (isUnlock)
            _currentStar = 0;
        else {
            if (timeUI.currentTimer < timeFor3Star)
                currentStar = 3;
            else if (timeUI.currentTimer < timeFor2Star)
                currentStar = 2;
            else
                currentStar = 1;

            _currentStar = currentStar;
        }

        if (PlayerPrefs.HasKey(stage.ToString()))
        {
            int last = PlayerPrefs.GetInt(stage.ToString());
            if (last < _currentStar)
            {
                PlayerPrefs.SetInt(stage.ToString(), _currentStar);
                stageStarList[stage - 1] = _currentStar;
            }
        }
        else
        {
            PlayerPrefs.SetInt(stage.ToString(), _currentStar);
            stageStarList.Add(_currentStar);
        }
    }

    void InitalUIValue()
    {
        scoreUi.Inital(_currentScore);
    }

    //--METHOD TO GET BEST SCORE--//
    public int GetBestScore()
    {
        if(PlayerPrefs.HasKey("BestScore"))
        {
            bestScore = PlayerPrefs.GetInt("BestScore");
            if(bestScore < currentScore)
            {
                bestScore = currentScore;
                PlayerPrefs.SetInt("BestScore", bestScore);
            }
        }
        else
        {
            bestScore = currentScore;
            PlayerPrefs.SetInt("BestScore", bestScore);
        }

        return bestScore;
    }

    //--METHOD TO CHECK STAGE STATUS--//
    void CheckStageStatus()
    {
        int _stage = 1;

        while(true)
        {
            if (!PlayerPrefs.HasKey(_stage.ToString()))
                break;
            stageStarList.Add(PlayerPrefs.GetInt(_stage.ToString()));
            _stage++;
        }
    }

    [ContextMenu("DeleteData")]
    public void DeleteData()
    {
        PlayerPrefs.DeleteAll();
    }
}
