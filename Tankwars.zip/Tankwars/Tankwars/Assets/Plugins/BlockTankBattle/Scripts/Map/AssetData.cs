﻿using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using UnityEngine.UI;

public class AssetData : MonoBehaviour
{
    public int stage = 1;

    private const string const_nameFile = "dataMapLevel";

#if UNITY_EDITOR
    // Method save data to json file to asset folder path
    public void SaveJsonData()
    {
        List<string> listJsonString = new List<String>();
        var blocks = FindObjectsOfType<Block>();

        foreach (Block block in blocks)
        {
            // Only save block type without wall base blocks
            if (block.typeBlock == TypeBlock.BrickStableWallBase || block.typeBlock == TypeBlock.BrickWallBase)
                continue;

			Data data = new Data (block.typeBlock, block.transform.position.x, block.transform.position.y);
			var str = JsonUtility.ToJson (data);

			listJsonString.Add (str);
		}

		System.IO.File.WriteAllLines (SettupPathSave (), listJsonString.ToArray ());

		// Debug 
		Debug.Log ("<color=yellow> Save file to:  </color>" + SettupPathLoad (stage));
	}
#endif

    public List<Data> LoadDataJson(int level)
    {
        List<Data> listDataBlocksCurrentLevel = new List<Data>();
        this.stage = level;

        // _text.text = File.Exists(SettupPathLoad());

        string[] stringJsonLines = System.IO.File.ReadAllLines(SettupPathLoad(level));

        // _text.text = "run";

        foreach (string line in stringJsonLines)
        {
            Data data = JsonUtility.FromJson<Data>(line);
            listDataBlocksCurrentLevel.Add(data);
        }

        return listDataBlocksCurrentLevel;
    }

    public List<Data> LoadDataJsonEdior(int level)
    {
        List<Data> listDataBlocksCurrentLevel = new List<Data>();
        this.stage = level;

        // _text.text = File.Exists(SettupPathLoad());

        string[] stringJsonLines = System.IO.File.ReadAllLines(SettupPathSave());

        // _text.text = "run";

        foreach (string line in stringJsonLines)
        {
            Data data = JsonUtility.FromJson<Data>(line);
            listDataBlocksCurrentLevel.Add(data);
        }

        return listDataBlocksCurrentLevel;
    }

//#if UNITY_EDITOR
    // Method settup path for save data
    string SettupPathSave()
	{
		string pathSaveData = Application.dataPath + "/data/" + const_nameFile;

		if (stage < 10)
			pathSaveData += ("0" + stage.ToString () + ".json");
		else
			pathSaveData += (stage.ToString () + ".json");

		return pathSaveData;
	}

//#endif

    // Method settup path for load
    string SettupPathLoad(int _level)
    {
        string pathSaveData = Application.persistentDataPath + "/" + const_nameFile;

        if (_level < 10)
            pathSaveData += ("0" + _level.ToString() + ".json");
        else
            pathSaveData += (_level.ToString() + ".json");

        return pathSaveData;
    }
}