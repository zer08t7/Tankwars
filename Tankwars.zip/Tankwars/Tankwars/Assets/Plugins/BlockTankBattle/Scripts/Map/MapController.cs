﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;

public class MapController : MonoBehaviour {

    public Text textStageSelect;
    public bool UnlockAll;

    private UIManager uiManager;
    private PersistentDataGameController persistentData;
    private List<int> stageStarList = new List<int>();

    private bool canClick = true;
    private int currentSelectStage = 1;

    void Awake()
    {
        uiManager = FindObjectOfType<UIManager>();
        persistentData = FindObjectOfType<PersistentDataGameController>();
    }

    void Start()
    {
        // Start focus to stage 1
        ActiveStage(1);

        // Unlock stage 1 when first game
        transform.GetChild(0).GetComponent<MapButtonController>().StageUnlock(0);

#if UNITY_EDITOR

        // Unlock all if you want test
        if (UnlockAll)
        {
            for (int i = 0; i < transform.childCount; i++)
                transform.GetChild(i).GetComponent<MapButtonController>().StageUnlock(0);
        }
# endif

        // Unlock stage
        for (int i=0;i<persistentData.stageStarList.Count;i++)
        {
            this.stageStarList.Add(persistentData.stageStarList[i]);
            var stage = transform.GetChild(i).GetComponent<MapButtonController>();
            stage.StageUnlock(persistentData.stageStarList[i]);
        }
    }

    //--METHOD CALL WHEN VICTORY--//
    public void CheckUnlock()
    {
        // Add first stage when list stage is emplty
        if(this.stageStarList.Count == 0 && persistentData.stageStarList.Count > 0)
            this.stageStarList.Add(persistentData.stageStarList[0]);

        // Set star again
        for (int i = 0; i < this.stageStarList.Count; i++)
        {
            var stage = transform.GetChild(i).GetComponent<MapButtonController>();
            stage.StageUnlock(persistentData.stageStarList[i]);
        }

        // Unlock new stage
        if (this.stageStarList.Count != persistentData.stageStarList.Count)
        {
            for (int i = this.stageStarList.Count; i < persistentData.stageStarList.Count; i++)
            {
                // Skip first stage
                if (i == 0)
                    continue;

                var stage = transform.GetChild(i).GetComponent<MapButtonController>();
                this.stageStarList.Add(persistentData.stageStarList[i]);            
                stage.UnlockNewStage(persistentData.stageStarList[i]);
            }
        }
    }

    public void ClickStage(int stageClick)
    {
        if (canClick)
        {
            MapButtonController stageButton = transform.GetChild(stageClick - 1).GetComponent<MapButtonController>();
            stageButton.ClickStage();
            canClick = false;

            if(stageClick >= 10)
                textStageSelect.text = "Stage " + stageClick;
            else
                textStageSelect.text = "Stage 0" + stageClick;

            StartCoroutine(CallUILoadStage(stageClick));

            uiManager.PlaySoundButtonClick();
        }
    }

    IEnumerator CallUILoadStage(int stage)
    {
        yield return new WaitForSeconds(1.0f);
        uiManager.LoadToStage(stage);
    }

    public void ChangeSelectStage(int stageSelect)
    {
        if (stageSelect != currentSelectStage && canClick)
        {
            DeactiveStage(currentSelectStage);
            currentSelectStage = stageSelect;
            ActiveStage(currentSelectStage);
        }
    }

    void ActiveStage(int stage)
    {
        MapButtonController stageButton = transform.GetChild(stage - 1).GetComponent<MapButtonController>();
        stageButton.ActiveStage();
    }

    void DeactiveStage(int stage)
    {
        MapButtonController stageButton = transform.GetChild(stage - 1).GetComponent<MapButtonController>();
        stageButton.DeactiveStage();
    }

    void OnEnable()
    {
        canClick = true;
    }
}
