﻿using UnityEngine;
using System.Collections;

public enum TypeBlock{
    BrickWallBase,
    BrickStableWallBase,
	Bound,
	BrickStable,
	Brick,
	Water,
	Tree,
    Box,
    Ground
}

public class Block : MonoBehaviour {

	public TypeBlock typeBlock = TypeBlock.Bound;

	// Default size each block
	public const float sizeBlocks = 0.25f;
	public Sprite[] sprites;
	public SpriteRenderer sprRender;

    // Particles for block
    public GameObject particleObj;

    // -- Method call when block have been destroyed -- //
    public void Explosion()
    {
        if (particleObj)
            SmartPool.Spawn(particleObj, transform.position, Quaternion.identity);


        if (this.gameObject.tag != "BaseWall")
            SmartPool.Despawn(this.gameObject);
        else
            this.gameObject.SetActive(false);
    }

    // -- METHOD CHANGE SPRITE WHEN EVENT GAME NEED TO DO THAT -- //
	public void ChangeSprite(int index)
	{
		sprRender.sprite = sprites [index];
	}

	#region Block resize editor
	[ContextMenu("ResizeSpriteWall")]
	public void ReseizeWall(){
		SpriteRenderer spr = GetComponentInChildren<SpriteRenderer> ();
		GetComponent<BoxCollider2D> ().size = new Vector2 (GameController.SIZE_OBJECT / 2, GameController.SIZE_OBJECT / 2);
		if(spr) {
			float scale_x = spr.bounds.size.x / sizeBlocks;
			float scale_y = spr.bounds.size.y / sizeBlocks;

			// change local scale
			spr.gameObject.transform.localScale = new Vector3(1/scale_x,1/scale_y);       
		}
	}
	#endregion

}


