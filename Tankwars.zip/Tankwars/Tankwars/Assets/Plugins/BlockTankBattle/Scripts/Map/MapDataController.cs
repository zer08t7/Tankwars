﻿using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using UnityEngine.UI;

// Struct ObjectPrefabs present number and sppecify prefabs will spawn into map
[Serializable]
public struct ObjectPrefab
{
	public int quantify;
	public GameObject prefabObject;
}

// Define data for each line json
[Serializable]
public struct Data
{
	public TypeBlock typeBlock;
	public float postionX,postionY;

	public Data(TypeBlock typeBlock,float posX,float posY)
	{
		this.typeBlock = typeBlock;
		this.postionX = posX;
		this.postionY = posY;
	}
}
	
public class MapDataController : MonoBehaviour 
{	
    [HideInInspector]
	public int level = 1;
	public List<ObjectPrefab> objectPrefabsMap;
	public List<TextAsset> textAssets;

	private List<Data> listDataBlocks;
	private List<Data> listDataBlocksCurrentLevel;

    private const string const_nameFile = "dataMapLevel";

	void Awake()
	{
		//// Preload prefabs
		//foreach(ObjectPrefab prefab in objectPrefabsMap)
		//	SmartPool.Preload (prefab.prefabObject, prefab.quantify);
	}

    void Start()
    {
        foreach (ObjectPrefab prefab in objectPrefabsMap)
            SmartPool.Preload(prefab.prefabObject, prefab.quantify);
    }

	// Call when active map
	public void ActiveMap(int _level)
	{
        LoadDataJson (_level);

		foreach(Data dataMap in listDataBlocksCurrentLevel) 
		{
			SmartPool.Spawn (GetGameobjectByType (dataMap.typeBlock), new Vector3 (dataMap.postionX, dataMap.postionY), Quaternion.identity);
		}
	}


    // Method deactive all map
    public void DeactiveAllMap()
    {
        var blocks = FindObjectsOfType<Block>();

        foreach(Block block in blocks)
        {
            if (block.tag != "BaseWall")
                SmartPool.Despawn(block.gameObject);
        }
    }

    // Method return gameobject with type block
    GameObject GetGameobjectByType( TypeBlock typeBlock)
	{
		foreach(ObjectPrefab prefab in objectPrefabsMap)
		{
			if (prefab.prefabObject.GetComponent<Block> ().typeBlock == typeBlock)
				return prefab.prefabObject;
		}

		return null;
	}

	#region Editor
	// Method save data binary file to asset folder path 
	[ContextMenu("Save Binary Data")]
	void SaveBinaryData()
	{
		listDataBlocks = new List<Data> ();

		var blocks = FindObjectsOfType<Block> ();

		foreach(Block block in blocks) {
			listDataBlocks.Add (new Data (block.typeBlock, (float) block.transform.position.x,(float) block.transform.position.y));
		}
			
		BinaryFormatter bf = new BinaryFormatter ();

		FileStream file = File.Open (SettupPathLoad(level), FileMode.Create);

		bf.Serialize (file, listDataBlocks);
		file.Close ();

		// Debug 
		Debug.Log ("<color=yellow> Save file to:  </color>" + SettupPathLoad (level));
	}

#if UNITY_EDITOR
    // Method save data to json file to asset folder path
    [ContextMenu("Save Json data")]
    void SaveJsonData()
    {
        List<string> listJsonString = new List<String>();
        var blocks = FindObjectsOfType<Block>();

        foreach (Block block in blocks)
        {
            // Only save block type without wall base blocks
            if (block.typeBlock == TypeBlock.BrickStableWallBase || block.typeBlock == TypeBlock.BrickWallBase)
                continue;

			Data data = new Data (block.typeBlock, block.transform.position.x, block.transform.position.y);
			var str = JsonUtility.ToJson (data);

			listJsonString.Add (str);
		}

		System.IO.File.WriteAllLines (SettupPathSave (), listJsonString.ToArray ());

		// Debug 
		Debug.Log ("<color=yellow> Save file to:  </color>" + SettupPathLoad (level));
	}
	#endif

	//Method load data current level
	[ContextMenu("Load Binary Data")]
	public List<Data> LoadBinaryData(int level = -1)
	{
		listDataBlocksCurrentLevel = new List<Data> ();

		if(level > 0)
			this.level = level;

		if(File.Exists(SettupPathLoad(level)))
		{
			BinaryFormatter bf = new BinaryFormatter ();
			FileStream file = File.Open (SettupPathLoad(level),FileMode.Open);

			listDataBlocksCurrentLevel = (List<Data>)bf.Deserialize (file);
			file.Close ();
		}
		return listDataBlocksCurrentLevel;
	}

	// Method load json data file
	[ContextMenu("Load Json Data")]
	public void LoadDataJson(int level)
	{
		listDataBlocksCurrentLevel = new List<Data> ();
		this.level = level;

       // _text.text = File.Exists(SettupPathLoad());

        string[] stringJsonLines = System.IO.File.ReadAllLines (SettupPathLoad (level));

       // _text.text = "run";

        foreach (string line in stringJsonLines)
		{
			Data data = JsonUtility.FromJson<Data> (line);
			listDataBlocksCurrentLevel.Add (data);
		}
	}

    // Method to save all text asset to folder persisten data on divice
    public void SaveAssetTextToPersistentData()
    {
        int level = 1;

        foreach (TextAsset text in textAssets)
        {
            string str = text.text;

            System.IO.File.WriteAllText(SettupPathLoad(level), str);
            level++;
        }
    }

#if UNITY_EDITOR
    // Method settup path for save data
    string SettupPathSave()
	{
		string pathSaveData = Application.dataPath + "/data/" + const_nameFile;

		if (level < 10)
			pathSaveData += ("0" + level.ToString () + ".json");
		else
			pathSaveData += (level.ToString () + ".json");

		return pathSaveData;
	}

	#endif

	// Method settup path for load
	string SettupPathLoad(int _level) 
	{
		string pathSaveData = Application.persistentDataPath + "/" + const_nameFile;

		if (_level < 10)
			pathSaveData += ("0" + _level.ToString () + ".json");
		else
			pathSaveData += (_level.ToString () + ".json");


        ///print(pathSaveData);
       // _text.text = pathSaveData;

        return pathSaveData;
	}

	#endregion

}