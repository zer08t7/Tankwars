﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class tankcontrollernew : MonoBehaviour {

	public float speed = 1;
	private int isturn = 1;

	void Update () {
		float h = Input.GetAxis ("Vertical");
		float w = Input.GetAxis ("Horizontal");
	
		Quaternion Right = Quaternion.Euler (0,0,-90);
		Quaternion Left = Quaternion.Euler (0,0,90);
		Quaternion Up = Quaternion.Euler (0,0,0);
		Quaternion Down = Quaternion.Euler (0,0,-180);

		if (h != 0) {
			if (h > 0) 
			{
				transform.rotation = Up;
				this.transform.position += new Vector3 (0, h * speed * Time.deltaTime, 0);
			} else 
			{
				transform.rotation = Down;
				
				this.transform.position += new Vector3 (0, h * speed * Time.deltaTime, 0);
			}
		}

		else if(w!=0)
		{
			if (w > 0) 
			{
				transform.rotation = Right;
				this.transform.position += new Vector3 (w * speed * Time.deltaTime,0, 0);
			} else 
			{
				transform.rotation = Left;
				this.transform.position += new Vector3 (w* speed * Time.deltaTime,0, 0);
			}	
		}
	}

	void OnCollisionEnter2D(Collision2D coll) {
		Debug.Log(coll.gameObject.name);
	}


}    

