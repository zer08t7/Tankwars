﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;

/// <summary>
/// Script to bring back control module on editor and pc
/// </summary>
public class InputModuleChange : MonoBehaviour {
    
    void Awake()
    {
#if UNITY_EDITOR
        this.gameObject.AddComponent<StandaloneInputModule>();
#endif
    }
}
