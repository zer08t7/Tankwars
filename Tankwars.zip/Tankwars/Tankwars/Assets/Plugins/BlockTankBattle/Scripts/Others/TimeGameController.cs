﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class TimeGameController : MonoBehaviour {

    public float currentTimer { get; set; }
    public Text timeText;

    private bool timerRun;

    // time struct ab:cd
    private int timeInt;

    private int a, b, c, d;

    void OnEnable()
    {
        currentTimer = 0.0f;
        timeInt = 0;

        timeText.text = "00:00";

        a = 0;
        b = 0;
        c = 0;
        d = 0;

        TimeStartRun();
    }

    void Start()
    {
        StateManager.Instance.OnStateGameStart += TimeStartRun;
    }

    public void TimeStartRun()
    {
        timerRun = true;
    }

    public void TimeStopRun()
    {
        timerRun = false;
    }

    void Update()
    {
        if(timerRun)
        {
            currentTimer += Time.deltaTime;

            DisplayTime(currentTimer);
        }
    }

    void DisplayTime(float timer)
    {
        if (timeInt != (int)timer)
        {
            d++;
            timeInt = (int)timer;

            if (d > 9)
            {
                d = 0;
                c++;
            }

            if (c > 5)
            {
                c = 0;
                b++;
            }

            if (b > 9)
            {
                b = 0;
                a++;
            }

            timeText.text = a.ToString() + b.ToString() + ":" + c.ToString() + d.ToString();
        }

    }

    public string GetTimeString()
    {
        return a.ToString() + b.ToString() + ":" + c.ToString() + d.ToString();
    }
}
