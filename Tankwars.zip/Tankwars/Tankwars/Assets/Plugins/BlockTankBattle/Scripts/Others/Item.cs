﻿using UnityEngine;
using System.Collections;

public class Item : MonoBehaviour {

    public TypeItems typeItem = TypeItems.Nucle;
    public GameObject FX_Deactive;

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player" || other.tag == "Shield")
        {
            SmartPool.Spawn(FX_Deactive, transform.position, Quaternion.identity);
            EventManager.Instance.PostNotification(EVENT_TYPE.ITEM_ACTIVE, this);
            SmartPool.Despawn(this.gameObject);
        }
    }
}
