﻿using UnityEngine;
using System.Collections;

public class InstantiteSpawPrefabs : MonoBehaviour {
    void Awake()
    {
        PreloadResource("Prefabs/FX",10);
        PreloadResource("Prefabs/Bullets",10);
        PreloadResource("Prefabs/Items",3);
        PreloadResource("Prefabs/Tanks",4);
        PreloadResource("Prefabs/Tiles", 100);
    }

    void PreloadResource(string pathFolder,int numberPreload)
    {
        GameObject[] fxPrefabs = Resources.LoadAll<GameObject>(pathFolder);

        for (int i = 0; i < fxPrefabs.Length; i++)
            SmartPool.Preload(fxPrefabs[i], numberPreload);
    }
}
