﻿using UnityEngine;
using System.Collections;

public class Sound_AutoPlay : MonoBehaviour {

    private AudioSource audioSource;

    void Awake()
    {
        audioSource = GetComponent<AudioSource>();
    }

    void OnEnable()
    {
        SoundManager.Instance.PlaySound(audioSource);
    }
}
