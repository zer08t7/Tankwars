﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class SoundManager : MonoBehaviour {

    public AudioClip[] bgSounds;
    public AudioSource audioSource;
    public static SoundManager Instance { get { return instance; } }

    public Sprite spriteSoundOn;
    public Sprite spriteSoundOff;
    public Image soundImage;

    private static SoundManager instance;

    private bool isSoundOn;                                                             // Save data with value: 1(sound on) and -1 (sound off)

    void Awake()
    {
        if(Instance  == null)
        {
            instance = this;
            DontDestroyOnLoad(this);

            // Get sound value
            if (PlayerPrefs.HasKey("isSoundOn"))
                isSoundOn = (PlayerPrefs.GetInt("isSoundOn") == 1) ? true : false;
            else
            {
                isSoundOn = true;
                SaveSound(isSoundOn);
            }

            soundImage.sprite = (isSoundOn) ? spriteSoundOn : spriteSoundOff;
        }
        else
        {
            DestroyImmediate(this);
        }       
    }

    //--METHOD PLAY SOUND BACKGROUND--//
    public void PlayBackgroundMusic()
    {
        if (!audioSource.isPlaying && isSoundOn)
        {
            audioSource.clip = bgSounds[Random.Range(0, bgSounds.Length)];
            audioSource.Play();
        }
    }


    //--METHOD STOP SOUND BACKGROUND--//
    public void StopPlayBackgroundMusic()
    {
        audioSource.Stop();
    }

    //--PLAY SOUND--//
    public void PlaySound(AudioSource audioSource,AudioClip soundEffect = null)
    {
        if (soundEffect)
            audioSource.clip = soundEffect;

        if(isSoundOn)
            audioSource.Play();
    }

    //--METHOD TURN OR TURN OFF VOLUME
    public void ChangeSoundSetting()
    {
        isSoundOn = (isSoundOn) ? false : true;
        soundImage.sprite = (isSoundOn) ? spriteSoundOn : spriteSoundOff;
    
        var sounds = FindObjectsOfType<AudioSource>();

        if (!isSoundOn)
        {
            foreach (AudioSource audio in sounds)
                audio.mute = true;
        }
        else
        {
            foreach (AudioSource audio in sounds)
                audio.mute = false;
        }

        SaveSound(isSoundOn);
    }

    //--SAVE SOUND--//
    void SaveSound(bool _isSoundOn)
    {
        int value = (_isSoundOn) ? 1 : -1;
        PlayerPrefs.SetInt("isSoundOn", value);
    }
}
