﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using System;

public class SliderMap : MonoBehaviour, IPointerUpHandler, IPointerExitHandler,IPointerEnterHandler

{
    public void OnPointerDown(PointerEventData eventData)
    {
        
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        print("enter");
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        print("exit");
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        
    }
}
