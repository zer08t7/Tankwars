﻿using UnityEngine;
using System.Collections;
using System;

public class TutorialController : MonoBehaviour,IListener {

    private Camera cameraMotion;
    private UIManager uiManager;
    private TankCannonController controllerShot;

    private bool showItemsCar;

    void Awake()
    {
        uiManager = FindObjectOfType<UIManager>();
    }
    void Start()
    {
        cameraMotion = Camera.main;
        EventManager.Instance.AddListener(EVENT_TYPE.ITEMS_CAR_SPAWN, this);
        EventManager.Instance.AddListener(EVENT_TYPE.ENEMY_SPECIAL_SPAWN, this);
        EventManager.Instance.AddListener(EVENT_TYPE.ENEMY_SPECIAL_DEAD, this);
    }

    void OnEnable()
    {
        StartCoroutine(StartTutorial());
    }

    IEnumerator StartTutorial()
    {
        yield return new WaitForSeconds(2.0f);
        
        Time.timeScale = 0.0f;

        uiManager.ActiveTutorial("Protect your base");
        yield return StartZoom(new Vector3(0, -3.5f));

        uiManager.ActiveTutorial("Destroy all base enemy");
        yield return StartZoom(new Vector3(0, 3.5f));

        yield return ShowTutorialIgnoreTimeScale("But now, you impossible attack base enemy", 3.5f);

        float timeStart = Time.realtimeSinceStartup;
        while (Time.realtimeSinceStartup < timeStart + 0.5f)
            yield return null;

        yield return ShowTutorialIgnoreTimeScale("Keep patient!!", 3.0f);

        uiManager.BackGamePlayFromTutorial();
        Time.timeScale = 1.0f;
    }

    public void StartZomTarget(Vector3 posZom)
    {
        StartCoroutine(StartZoom(posZom));
    }

    IEnumerator StartZoom(Vector3 posZom)
    {
        float currentTimeScale = Time.timeScale;

        while(cameraMotion.orthographicSize > 1.202f)
        {
            cameraMotion.orthographicSize = Mathf.Lerp(cameraMotion.orthographicSize, 1.2f, Time.fixedDeltaTime*8.0f);
            cameraMotion.transform.position = Vector3.Lerp(cameraMotion.transform.position,new Vector3( posZom.x,posZom.y,-10), Time.fixedDeltaTime * 8.0f);
            Time.timeScale = Mathf.MoveTowards(Time.timeScale, 0.0f, Time.fixedDeltaTime * 8.0f);
            yield return null;
        }

        float timeStart = Time.realtimeSinceStartup;

        // Stop to wait for player
        while (Time.realtimeSinceStartup < timeStart + 2.0f)
            yield return null;
        uiManager.DeactiveTutorial();

        while (cameraMotion.orthographicSize < 4 - 0.02f)
        {
            cameraMotion.orthographicSize = Mathf.Lerp(cameraMotion.orthographicSize, 4, Time.fixedDeltaTime * 8.0f);
            cameraMotion.transform.position = Vector3.Lerp(cameraMotion.transform.position, new Vector3(0, 0, -10), Time.fixedDeltaTime * 8.0f);
            Time.timeScale = Mathf.MoveTowards(Time.timeScale, currentTimeScale, Time.fixedDeltaTime * 8.0f);
            yield return null;
        }

        Time.timeScale = currentTimeScale;
        cameraMotion.orthographicSize = 4.0f;
    }

    IEnumerator ShowTutorialIgnoreTimeScale(string textGuide,float timeWait)
    {
        uiManager.ActiveTutorial(textGuide);

        float timeStart = Time.realtimeSinceStartup;
        while (Time.realtimeSinceStartup < timeStart + timeWait)
            yield return null;
        uiManager.DeactiveTutorial();
    }

    IEnumerator ShowTutorialZomObj(Transform posTarget,string textGuide)
    {
        yield return new WaitForSeconds(0.5f);

        controllerShot = GameObject.FindGameObjectWithTag("Player").GetComponent<TankCannonController>();
        controllerShot.CancelShot();
        Time.timeScale = 0.0f;

        controllerShot.CancelShot();
        uiManager.ActiveTutorial(textGuide);
        if (posTarget)
            yield return StartZoom(posTarget.position);
        else
            yield return StartZoom(new Vector3(0, 3.5f));

        uiManager.BackGamePlayFromTutorial();
        Time.timeScale = 1.0f;
    }

    public void OnEvent(EVENT_TYPE Event_Type, Component Sender, object Param = null)
    {
        if (Event_Type == EVENT_TYPE.ITEMS_CAR_SPAWN & !showItemsCar)
        {
            Transform target = Sender.transform;
            StartCoroutine(ShowTutorialZomObj(target, "Kill car to get items!!"));
            showItemsCar = true;
        }
        else if (Event_Type == EVENT_TYPE.ENEMY_SPECIAL_SPAWN)
        {
            Transform target = Sender.transform;
            StartCoroutine(ShowTutorialZomObj(target, "Kill special tank now!!"));
        }
        else if (Event_Type == EVENT_TYPE.ENEMY_SPECIAL_DEAD)
            StartCoroutine(ShowTutorialZomObj(null, "Now, you can attack base enemy. Destroy it now!!"));

    }
}
