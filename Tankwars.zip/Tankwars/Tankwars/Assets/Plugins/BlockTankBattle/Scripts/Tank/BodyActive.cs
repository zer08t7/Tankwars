﻿using UnityEngine;
using System.Collections;

public class BodyActive : MonoBehaviour
{

    // Contain sprite make effect
    public SpriteRenderer
        cannonSprite,
        bodySprite;

    public float offset = 0.5f;

    // Start position
    private float
        cannonStartPosY ,
        bodyStartPosY ;

    // Backup
    private float
        cannonOriginalPosY,
        bodyOriginalPosY;

    void Awake()
    {
        // Backup
        cannonOriginalPosY = cannonSprite.transform.localPosition.y;
        bodyOriginalPosY = bodySprite.transform.localPosition.y;

        // Get start pos
        cannonStartPosY = cannonOriginalPosY + offset;
        bodyStartPosY = bodyOriginalPosY - offset;
    }

    //--METHOD YOU WANT MAKE EFFECT ACTIVE--//
    public void Deactive()
    {
        StartCoroutine(DeactiveEffect());
    }

    //--METHOD IMPLEMENT EFFECT--//
    IEnumerator DeactiveEffect()
    {
        while (cannonSprite.color.a > 0.01f)
        {
            // Clear color
            cannonSprite.color = new Color(1, 1, 1, Mathf.Lerp(cannonSprite.color.a, 0, Time.deltaTime * 60.0f));
            bodySprite.color = new Color(1, 1, 1, Mathf.Lerp(bodySprite.color.a, 0, Time.deltaTime * 60.0f));

            // Move sprite 
            cannonSprite.transform.Translate(Vector3.right * Time.deltaTime*10.0f);
            bodySprite.transform.Translate(-Vector3.right * Time.deltaTime*10.0f);

            yield return null;
        }

        // Reset
        cannonSprite.color = new Color(1, 1, 1, 1);
        bodySprite.color = new Color(1, 1, 1, 1);
        cannonSprite.transform.localPosition = new Vector3(0, cannonSprite.transform.localPosition.y);
        bodySprite.transform.localPosition = new Vector3(0, bodySprite.transform.localPosition.y);

        // Deactive
        this.gameObject.SetActive(false);
    }

    //--METHOD YOU WANT MAKE EFFECT DEACTIVE--//
    public void Active()
    {
        StartCoroutine(ActiveEffect());
    }

    //--METHOD IMPLEMENT EFFECT--//
    IEnumerator ActiveEffect()
    {
        cannonSprite.transform.localPosition = new Vector3(0, cannonStartPosY);
        bodySprite.transform.localPosition = new Vector3(0, bodyStartPosY);

        while(Vector3.Distance(cannonSprite.transform.localPosition,new Vector3(0,cannonOriginalPosY)) > 0.02f)
        {
            float currentPosY = cannonSprite.transform.localPosition.y;
            cannonSprite.transform.localPosition = new Vector3(0, Mathf.MoveTowards(currentPosY, cannonOriginalPosY, Time.deltaTime * 2.5f));

            currentPosY = bodySprite.transform.localPosition.y;
            bodySprite.transform.localPosition = new Vector3(0, Mathf.MoveTowards(currentPosY, bodyOriginalPosY, Time.deltaTime * 2.5f));

            yield return null;
        }
    }

    //--METHOD GUARANTEED--//
    void OnDisable()
    {
        cannonSprite.color = new Color(1, 1, 1, 1);
        bodySprite.color = new Color(1, 1, 1, 1);
        cannonSprite.transform.localPosition = new Vector3(0, cannonSprite.transform.localPosition.y);
        bodySprite.transform.localPosition = new Vector3(0, bodySprite.transform.localPosition.y);
    }
}
