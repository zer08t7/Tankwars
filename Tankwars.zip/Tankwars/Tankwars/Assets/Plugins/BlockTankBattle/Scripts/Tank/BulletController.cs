﻿using UnityEngine;
using System.Collections;

public class BulletController : MonoBehaviour
{
    public TypeBlock[] typeBlockCanDestroys;
    public float speed = 2.0f;
    public LayerMask vulnerableObjectLayer;
    public LayerMask stableObjectLayer;

    public GameObject explosionPrefabs;

    private float currentSpeed;
    protected GameObject objectBelong;                            // Prevent object shot to self

    //--METHOD INITIAL BULLET--//
    public void IntialBullet(GameObject objectBelong)
    {
        currentSpeed = speed;
        this.objectBelong = objectBelong;
    }

    void Update()
    {
        transform.Translate(Vector3.up * Time.deltaTime * currentSpeed);
    }


    void OnTriggerEnter2D(Collider2D other)
    {
        // Ignore self
        if (other.gameObject.GetInstanceID() == objectBelong.GetInstanceID())
            return;

        if (explosionPrefabs)
            SmartPool.Spawn(explosionPrefabs, transform.position, Quaternion.identity);

        currentSpeed = 0.0f;

        // Check stable object
        if ((stableObjectLayer.value & (1 << other.gameObject.layer)) > 0 )
        {
            SmartPool.Spawn(explosionPrefabs, transform.position, Quaternion.identity);
            SmartPool.Despawn(this.gameObject);
            return;
        }

        // hit to vulnerable oject
        if ((vulnerableObjectLayer.value & (1 << other.gameObject.layer)) > 0)
        {
            // Check hit shield
            if(other.tag == "Shield")
            {
                SmartPool.Spawn(explosionPrefabs, transform.position, Quaternion.identity);
                SmartPool.Despawn(this.gameObject);
                return;
            }

            // Check if tank layer
            if (other.gameObject.layer == 10 || other.gameObject.layer == 17)
            {
                var tankObj = other.GetComponent<TankObject>();

                if (tankObj.currentArmor > 0)
                    tankObj.currentArmor--;
                else
                    tankObj.currentHealth--;

                SmartPool.Despawn(this.gameObject);
                return;
            }

            // Hit bullet
            if (other.tag == "Bullet")
            {
                SmartPool.Despawn(other.gameObject);
                SmartPool.Despawn(this.gameObject);
                return;
            }

            // Hit star
            if (other.tag == "Star")
            {
                other.GetComponent<StarBase>().CallDestroyBase();
                SmartPool.Despawn(this.gameObject);
                return;
            }

            // Hit block
            var block = other.GetComponent<Block>();
            if(block)
            {

                if (block.typeBlock == TypeBlock.Water)
                    return;

                foreach(TypeBlock typeBlock in typeBlockCanDestroys)
                {
                    if(typeBlock == block.typeBlock)
                    {
                        block.Explosion();
                        StartCoroutine( DeactiveBullet());
                        return;
                    }
                }

                SmartPool.Despawn(this.gameObject);
            }
        }
    }

    IEnumerator DeactiveBullet()
    {
        yield return new WaitForSeconds(0.00f);
        SmartPool.Despawn(this.gameObject);
    }
}
