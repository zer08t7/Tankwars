﻿using UnityEngine;
using System.Collections;


//--THIS SCRIPT WILL MAKE PLAYER CAN NOT GET DAMAGE FROM BULLET ENEMY--//
public class ShieldPlayer : MonoBehaviour {

    public float timeAlive = 3.0f;                      // Value will set outside class to make exist in specific time
    public GameObject bodyRotate;
    public SpriteRenderer sprite;

    private float timeActive;  
    private float lastRotate;

    //--WHEN OBJECT ATTACH THIS SCRIPT ACTIVE, IT WILL MAKE PLAYER HAVE SHIELD--//
    void OnEnable()
    {
        GameObject player = transform.root.gameObject;
        player.tag = "Shield";

        timeActive = Time.time;
        StartCoroutine(StartActiveShield());
    }

    public void IntialShield()
    {
        timeActive = Time.time;        
    }

    //--METHOD ACTIVE SHIELD--//
    IEnumerator StartActiveShield()
    {
        transform.localScale = Vector2.zero;

        // Effect active
        while(transform.localScale.x < 0.99)
        {
            transform.localScale = Vector3.MoveTowards(transform.localScale, new Vector3(1, 1, 1), Time.deltaTime * 3.0f);
            yield return null;
        }

        // Check time
        while (Time.time - timeActive < timeAlive)
            yield return null;

        // Effect deactive

         while(sprite.color.a > 0.1f)
        {
            sprite.color = Color32.Lerp(sprite.color, Color.clear, Time.deltaTime);
            yield return null;
        }

        gameObject.SetActive(false);
    }

    //--WHEN DISABLE, PLAYER WILL RESET--//
    void OnDisable()
    {
        GameObject player = transform.root.gameObject;
        player.tag = "Player";
        transform.localScale = Vector2.zero;
        sprite.color = new Color32(255, 255, 255, 221);
    }
}
