﻿using UnityEngine;
using System.Collections;

public class TankItems : TankObject {

    public override int currentHealth
    {
        set
        {
            _currentHealth = Mathf.Clamp(value, 0, MaxHealth);

            if (_currentHealth == 0)
            {
                // Spawn effect explosion
                if (FX_Explosion)
                    SmartPool.Spawn(FX_Explosion, transform.position, Quaternion.identity);

                // Call event to sapwn items
                EventManager.Instance.PostNotification(EVENT_TYPE.ITEM_SPAWN, this);

                // Call event to sapwn new enemy
                EventManager.Instance.PostNotification(EVENT_TYPE.ENEMY_DEAD, this);

                SmartPool.Despawn(this.gameObject);
            }
        }
    }
}
