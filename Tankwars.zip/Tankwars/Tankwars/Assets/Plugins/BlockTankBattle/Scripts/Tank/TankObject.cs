﻿using UnityEngine;
using System.Collections;
using System;

public class TankObject : MonoBehaviour,IListener {

    public int MaxHealth;
    public GameObject FX_Explosion;
    public GameObject FX_GetHit;

    public AudioSource soundfx_getHit;

    protected int _currentArmor;
    public virtual int currentArmor
    {
        get { return _currentArmor; }
        set { }
    }

    protected int _currentHealth;
    public virtual int currentHealth
    {
        get { return _currentHealth; }
        set
        {
            // Spawn effect get hit
            if(currentHealth != 0)
            {
                var fx = SmartPool.Spawn(FX_GetHit, transform.position, Quaternion.identity);
                fx.transform.SetParent(transform);
            }
        }
    }

    //--INTIAL HEALTH FOR TANK--//
    void OnEnable()
    {
        _currentHealth = MaxHealth;
        StateManager.Instance.OnStateGameStart += Reset;
    }

    //--METHOD CALL RESET TANK WHEN LEVEL START--//
    public virtual void Reset()
    {
        
    }

    // Tank Player and Tank Enemy need overrite method
    public virtual void OnEvent(EVENT_TYPE Event_Type, Component Sender, object Param = null)
    {
        
    }
}
