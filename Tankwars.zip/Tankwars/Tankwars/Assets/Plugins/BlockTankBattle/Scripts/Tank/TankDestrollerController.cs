﻿using UnityEngine;
using System.Collections;

public class TankDestrollerController : MonoBehaviour {

    public LayerMask layerDestroy;
    public TypeBlock[] typeBlockCanDestroys;

    void OnTriggerEnter2D(Collider2D other)
    {
        if ((layerDestroy.value & (1 << other.gameObject.layer)) > 0)
        {
            var block = other.GetComponent<Block>();
            if(block)
            {
                foreach (TypeBlock typeBlock in typeBlockCanDestroys)
                {
                    if (typeBlock == block.typeBlock)
                    {
                        block.Explosion();
                        return;
                    }
                }
            }
        }
    }
}
