﻿using UnityEngine;
using System.Collections;

public enum TypeControl
{
	Player,
	AI,
    Items
}

public class TankController : MonoBehaviour {

	private const float skinWidth = .02f;
    private const int TotalHorizontalRays = 4;
	private const int TotalVerticalRays = 4;

	public LayerMask PlatformMask;
	public TypeControl typeControl = TypeControl.Player;

	public Vector2 Velocity { get { return _velocity; } }
	public bool HandleCollisions { get; set; }

	private Vector2 _velocity;
	private Transform _transform;	
	private BoxCollider2D _boxCollider;

	public bool hitWall{ get;private set;}

	private Vector3
	_activeGlobalPlatformPoint,
	_activeLocalPlatformPoint;

	private Vector3
	_raycastTopLeft,
	_raycastBottomRight,
	_raycastBottomLeft;

	private float
	_verticalDistanceBetweenRays,
	_horizontalDistanceBetweenRays;


    private bool isRight;
    private bool isUp;

	private bool hitObstacles;
	private bool hitAngle01;
	private bool hitAngle02;

    public void Awake()
    {
        HandleCollisions = true;
		_transform = transform;
		_boxCollider = GetComponent<BoxCollider2D>();

		// horizontalDistanceBetweenRays
		var colliderWidth = _boxCollider.size.x * Mathf.Abs(transform.localScale.x) - (2 * skinWidth);
		_horizontalDistanceBetweenRays = colliderWidth / (TotalVerticalRays - 1);

		// verticalDistanceBetweenRays
		var colliderHeight = _boxCollider.size.y * Mathf.Abs(transform.localScale.y) - (2 * skinWidth);
		_verticalDistanceBetweenRays = colliderHeight / (TotalHorizontalRays - 1); 
	}

	public void SetHorizontalForce(float x)
	{
		_velocity.x = x;
	}

	public void SetVerticalForce(float y)
	{
		_velocity.y = y;
	}

	public void LateUpdate()
	{      
		hitWall = false;

		Move(Velocity*Time.deltaTime);
	}

    private void Move(Vector2 deltaMovement)
    {
        if (HandleCollisions)
        {
            CaculateRayOrigins();

            if (typeControl == TypeControl.AI || typeControl == TypeControl.Items)
            {
                if (Mathf.Abs(deltaMovement.x) > .001f)
                    MoveHorizontally(ref deltaMovement);

                if (Mathf.Abs(deltaMovement.y) > .001f)
                    MoveVertically(ref deltaMovement);
            }
            else
            {
                MoveHorizontally(ref deltaMovement);
                MoveVertically(ref deltaMovement);
            }
		}

		// Apply deltaMovement
		_transform.Translate(deltaMovement, Space.World);

	}

    // Caculate postion ray to raycast
	private void CaculateRayOrigins()
	{
		var size = new Vector2(_boxCollider.size.x ,_boxCollider.size.y) / 2;
		var center = new Vector2(_boxCollider.offset.x , _boxCollider.offset.y);

		_raycastTopLeft = _transform.position + new Vector3(center.x - size.x + skinWidth, center.y + size.y - skinWidth);
		_raycastBottomRight = _transform.position + new Vector3(center.x + size.x - skinWidth, center.y - size.y + skinWidth);
		_raycastBottomLeft = _transform.position + new Vector3(center.x - size.x + skinWidth, center.y - size.y + skinWidth);
	}

    // Move horizontal	
    private void MoveHorizontally(ref Vector2 deltaMovement, bool slope = false, bool isRight = false)
    {
        var isGoingRight = deltaMovement.x > 0;

        if (deltaMovement.x == 0)
            isGoingRight = this.isRight;

        if (slope)
        {
            isGoingRight = isRight;
            this.isRight = isRight;
        }

        var rayDistance = Mathf.Abs(deltaMovement.x) + skinWidth;
        var rayDirection = isGoingRight ? Vector2.right : -Vector2.right;
        var rayOrigin = isGoingRight ? _raycastBottomRight : _raycastBottomLeft;

        hitAngle01 = false;
        hitAngle02 = false;

        for (var i = 0; i < TotalHorizontalRays; i++)
        {

            var rayVector = new Vector2(rayOrigin.x, rayOrigin.y + (i * _verticalDistanceBetweenRays));

            Debug.DrawRay(rayVector, rayDirection * rayDistance, Color.red);

            var rayCastHit = Physics2D.Raycast(rayVector, rayDirection, rayDistance, PlatformMask);

            if (rayCastHit.transform.gameObject.GetInstanceID() == gameObject.GetInstanceID())
            {
                rayVector = (isGoingRight) ? new Vector2(rayOrigin.x + skinWidth + 0.01f, rayVector.y) : new Vector2(rayOrigin.x - skinWidth - 0.01f, rayVector.y);
                rayCastHit = Physics2D.Raycast(rayVector, rayDirection, rayDistance - skinWidth, PlatformMask);
            }

            if (!rayCastHit)
                continue;

            if (typeControl == TypeControl.Player && rayCastHit.transform.tag != "Enemy")
            {
                if (i == 0)
                {
                    if (!slope)
                        hitAngle01 = true;
                    continue;
                }

                if (i == TotalHorizontalRays - 1)
                {

                    if (!slope)
                        hitAngle02 = true;
                    if (!hitAngle01)
                        continue;
                }

                hitObstacles = true;
            }
            else if (typeControl == TypeControl.AI)
            {
                if (rayCastHit.transform.gameObject.tag != "Player")
                    hitWall = true;
                else
                    hitWall = false;
            }
            else
                hitWall = true;

            if (typeControl == TypeControl.Player && rayCastHit.transform.tag == "Enemy" && Mathf.Abs(deltaMovement.x) < 0.01f)
                continue;

            deltaMovement.x = rayCastHit.point.x - rayVector.x;
			rayDistance = Mathf.Abs(deltaMovement.x);

			if (isGoingRight)
				deltaMovement.x -= skinWidth;
			else
				deltaMovement.x += skinWidth;

			if (rayDistance < skinWidth + .00001f)
				break;
		}

		if (typeControl == TypeControl.Player && !slope)
		{
			if (!hitObstacles) {
                if (hitAngle01 )
                    MoveVertically(ref deltaMovement, true, false);

                if (hitAngle02 )
                    MoveVertically(ref deltaMovement, true, true);
            }
		}

        // Reset
		hitObstacles = false;
	}

    // Move vertical
    private void MoveVertically(ref Vector2 deltaMovement, bool slope = false, bool isUp = false)
	{
		var isGoingUp = deltaMovement.y > 0;

        if (deltaMovement.y == 0)
            isGoingUp = this.isUp;

        if (slope)
        {
            isGoingUp = isUp;
            this.isUp = isUp;
        }

		var rayDistance = Mathf.Abs(deltaMovement.y) + skinWidth;
		var rayDirection = isGoingUp ? Vector2.up : -Vector2.up;
		var rayOrigin = isGoingUp ? _raycastTopLeft : _raycastBottomLeft;

        hitAngle01 = false;
        hitAngle02 = false;

        for (var i = 0; i < TotalVerticalRays; i++)
		{

			var rayVector = new Vector2(rayOrigin.x + (i * _horizontalDistanceBetweenRays), rayOrigin.y);

			Debug.DrawRay(rayVector, rayDistance * rayDirection, Color.red);

			var rayCastHit = Physics2D.Raycast(rayVector, rayDirection, rayDistance, PlatformMask);

			if (rayCastHit.transform.gameObject.GetInstanceID () == gameObject.GetInstanceID ())
			{
				rayVector = (isGoingUp) ?  new Vector2(rayVector.x, rayOrigin.y + skinWidth + 0.01f) : new Vector2(rayVector.x, rayOrigin.y - skinWidth -0.01f) ;
				rayCastHit =  Physics2D.Raycast(rayVector, rayDirection, rayDistance - skinWidth, PlatformMask);
			}
				
			if (!rayCastHit)
				continue;

            if (typeControl == TypeControl.Player && rayCastHit.transform.tag != "Enemy")
            {
                if (i == 0)
                {
                    if (!slope)
                        hitAngle01 = true;
                    continue;
                }

                if (i == TotalVerticalRays - 1)
                {
                    if (!slope)
                        hitAngle02 = true;
                    if (!hitAngle01)
                        continue;
                }

                hitObstacles = true;
            }
            else if (rayCastHit.transform.tag != "Player")
                hitWall = true;

            else
                hitWall = true;

            if (typeControl == TypeControl.Player && rayCastHit.transform.tag == "Enemy" && Mathf.Abs(deltaMovement.y) < 0.01f)
                continue;

            deltaMovement.y = rayCastHit.point.y - rayVector.y;
			rayDistance = Mathf.Abs(deltaMovement.y);

			if (isGoingUp)
				deltaMovement.y -= skinWidth;
			else
				deltaMovement.y += skinWidth;

			if (rayDistance < skinWidth + .0001f)
				break;

		}

        if (typeControl == TypeControl.Player && !slope)
        {
            if (!hitObstacles)
            {
                if (hitAngle01)
                    MoveHorizontally(ref deltaMovement, true, false);

                if (hitAngle02)
                    MoveHorizontally(ref deltaMovement, true, true);
            }
        }

        // Reset
        hitObstacles = false;
	}

}
