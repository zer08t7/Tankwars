﻿using UnityEngine;
using System.Collections;

public class ControllerInput : MonoBehaviour {
    public bool IsDead { get; set; }

    public float DefaultMaxSpeed = 8;
    public float ModifyMaxSpeed = -1;
    public float Speed { get { return ModifyMaxSpeed != -1 ? ModifyMaxSpeed : DefaultMaxSpeed; } }
    public TypeControl typeControl = TypeControl.AI;

    private TankCannonController cannon;
    private SpriteRenderer bodySprite;
	private TankController _controller;

    private float _normalizedHorizontialSpeed;
	private float _normalVerticalSpeed;

    private bool moveLeft;
    private bool moveRight;

    public void Awake()
    {
		_controller = GetComponent<TankController>();
		bodySprite = GetComponentInChildren<SpriteRenderer> ();
        cannon = GetComponent<TankCannonController>();
    }

    public void OnEnable()
    {
        // Reset speed
        ModifyMaxSpeed = -1;
    }

    public void Update()
    {
#if UNITY_EDITOR
        if (!IsDead && typeControl == TypeControl.Player)
            HandleInput();
#endif

        if (IsDead)
        {
            print(IsDead);
            _controller.SetHorizontalForce(0);
        }
        else
        {
            _controller.SetHorizontalForce(_normalizedHorizontialSpeed * Speed);
            _controller.SetVerticalForce(_normalVerticalSpeed * Speed);
        }
    }

	#if UNITY_EDITOR
    private void HandleInput()
    {
        if (Input.GetMouseButtonDown(0))
            cannon.Shot();

		if (Input.GetKey (KeyCode.W)) {
			_normalVerticalSpeed = 1;
			_normalizedHorizontialSpeed = 0;
			bodySprite.transform.eulerAngles = new Vector3 (0, 0, 0);
		}else if(Input.GetKey(KeyCode.S))
		{
			_normalVerticalSpeed = -1;
			_normalizedHorizontialSpeed = 0;
			bodySprite.transform.eulerAngles = new Vector3 (0, 0, 180);
		}else if(Input.GetKey(KeyCode.D))
		{
			_normalizedHorizontialSpeed = 1;
			_normalVerticalSpeed = 0;
			bodySprite.transform.eulerAngles = new Vector3 (0, 0, 270);
		}else if(Input.GetKey(KeyCode.A))
		{
			bodySprite.transform.eulerAngles = new Vector3 (0, 0, 90);
			_normalizedHorizontialSpeed = -1;
			_normalVerticalSpeed = 0;
		}else{
			_normalVerticalSpeed = 0;
			_normalizedHorizontialSpeed = 0;
		}
    }
	#endif
		

	public void MoveUp()
	{
		_normalVerticalSpeed = 1;
		_normalizedHorizontialSpeed = 0;
		bodySprite.transform.eulerAngles = new Vector3 (0, 0, 0);
	}

	public void MoveDown()
	{
		_normalVerticalSpeed = -1;
		_normalizedHorizontialSpeed = 0;
		bodySprite.transform.eulerAngles = new Vector3 (0, 0, 180);
	}

    public void MoveLeft()
    {
		_normalizedHorizontialSpeed = -1;
		_normalVerticalSpeed = 0;
		bodySprite.transform.eulerAngles = new Vector3 (0, 0, 90);
    }

    public void MoveRight()
    {
		_normalizedHorizontialSpeed = 1;
		_normalVerticalSpeed = 0;
		bodySprite.transform.eulerAngles = new Vector3 (0, 0, 270);
    }

    public void Release()
    {
		_normalVerticalSpeed = 0;
		_normalizedHorizontialSpeed = 0;
    }
}
