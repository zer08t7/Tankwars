﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(Rigidbody2D))]
public class Bullet : MonoBehaviour {

	public float speed  = 2.0f;
	public LayerMask vulnerableObjectLayer;
	public LayerMask stableObjectLayer;

    public GameObject explosionPrefabs;

	private float currentSpeed;
    protected GameObject objectBelong;                            // Prevent object shot to self

    //--METHOD INITIAL BULLET--//
	public void IntialBullet(GameObject objectBelong) 
	{
		currentSpeed = speed;
        this.objectBelong = objectBelong;
	}

	void Update(){
		transform.Translate (Vector3.up * Time.deltaTime * currentSpeed);
	}

	public virtual void OnTriggerEnter2D(Collider2D other)
    {
         currentSpeed = 0.0f;

        // hit to vulnerable oject
        if ((vulnerableObjectLayer.value & (1<<other.gameObject.layer)) > 0)
		{

            // Hit bullet
            if (other.tag == "Bullet")
            {
                SmartPool.Despawn(other.gameObject);
                SmartPool.Despawn(this.gameObject);
                return;
            }

            if (other.tag == "Star")
                other.GetComponent<StarBase>().CallDestroyBase();                                       // Call destroy base
            else
                other.GetComponent<Block>().Explosion();                                               // Deactive with pool object block

			currentSpeed = 0.0f;
            StartCoroutine (DeactiveBullet ());
        }

        // hit to block
        if ((stableObjectLayer.value & (1 << other.gameObject.layer)) > 0)
        {
            StopCoroutine(DeactiveBullet());
            SmartPool.Despawn(this.gameObject);
        }
	}

	IEnumerator DeactiveBullet(){
		yield return new WaitForSeconds (0.00f);
        SmartPool.Despawn(this.gameObject);	
	}
}