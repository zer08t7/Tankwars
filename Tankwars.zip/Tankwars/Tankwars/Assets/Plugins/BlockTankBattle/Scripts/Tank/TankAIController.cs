﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public enum TypeAI
{
	Type01,
	TYpe02
}

public enum TypeAIFireRate
{
	Constaint,
	Random,
    None
}

public enum TypeMove
{
	Forward,
	Backward,
	Left,
	Right,
	None
}

[RequireComponent(typeof(TankController))]
public class TankAIController : MonoBehaviour
{

    ControllerInput aiController;
    TankController tankController;

    public float fireRate = 5.0f;
    public int maxNumberShot = 2;
    public TypeAIFireRate typeFireRate = TypeAIFireRate.Constaint;

    public ParticleSystem FX_Freezing;

    private float lastTimeShot = 0.0f;
    private float currentFireRate;

    public float timeDecisison = 5.0f;                                                  // time make AI Decision
    private float lastTimeMakeDecision = 0.0f;

    private TypeMove currentDirectMove;
    private List<TypeMove> listDirectCanMove;

    private TankCannonController cannon;

    private BoxCollider2D boxColldier;
    private float offset = 0.02f;
    private LayerMask layerObstacles;

    private bool isStop = false;

    private RaycastHit2D[]
        raysSideRight_Bottom,
        raysSideLeft_Top;

    void Awake()
    {
        tankController = GetComponent<TankController>();
        aiController = GetComponent<ControllerInput>();
        boxColldier = GetComponent<BoxCollider2D>();
        cannon = GetComponent<TankCannonController>();

        raysSideLeft_Top = new RaycastHit2D[2];
        raysSideRight_Bottom = new RaycastHit2D[2];
        listDirectCanMove = new List<TypeMove>();

        layerObstacles = tankController.PlatformMask;

        currentFireRate = Random.Range(fireRate - 1.5f, fireRate + 1.5f);
        currentDirectMove = TypeMove.Right;
    }

    void Update()
    {
        if (!isStop)
        {
            if (Time.time - lastTimeShot > currentFireRate)
            {
                switch (typeFireRate)
                {
                    case TypeAIFireRate.Constaint:
                        StartCoroutine(AIShot(maxNumberShot));
                        break;
                    case TypeAIFireRate.Random:
                        int numberShot = Random.Range(1, maxNumberShot + 1);
                        fireRate = Random.Range(2, 5);
                        StartCoroutine(AIShot(numberShot));
                        break;
                    default:
                        break;
                }

                currentFireRate = Random.Range(fireRate - 1.5f, fireRate + 1.5f);
                lastTimeShot = Time.time;
            }

            if (Time.time - lastTimeMakeDecision > 0.2f)
            {
                RaycastSideAITank(currentDirectMove);

                // AI make dicission
                if (listDirectCanMove.Count > 0 && Time.time - lastTimeMakeDecision > timeDecisison)
                    MakeDecision();
                else if (tankController.hitWall)
                    MakeDecision(true);

                // Reset list
                listDirectCanMove.Clear();
            }

            AIMove(currentDirectMove);
        }
    }

    // Method call shot
    IEnumerator AIShot(int numberShot)
    {
        for (int i = 0; i < numberShot; i++)
        {
            cannon.Shot();
            yield return new WaitForSeconds(cannon.fireRate + 0.001f);
        }
    }

    void RaycastSideAITank(TypeMove typeMove)
    {
        float sizeObject = boxColldier.size.x / 2;

        if (typeMove == TypeMove.Forward || typeMove == TypeMove.Backward)
        {
            Vector3 posLeftTop = transform.position + new Vector3(-sizeObject - offset, sizeObject - offset);
            Vector3 posLeftBotton = transform.position + new Vector3(-sizeObject - offset, -sizeObject + offset);
            Vector3 posRightTop = transform.position + new Vector3(sizeObject + offset, sizeObject - offset);
            Vector3 posRightBottom = transform.position + new Vector3(sizeObject + offset, -sizeObject + offset);

            raysSideLeft_Top[0] = Physics2D.Raycast(posLeftTop, -transform.right, offset, layerObstacles);
            raysSideLeft_Top[1] = Physics2D.Raycast(posLeftBotton, -transform.right, offset, layerObstacles);
            raysSideRight_Bottom[0] = Physics2D.Raycast(posRightTop, transform.right, offset, layerObstacles);
            raysSideRight_Bottom[1] = Physics2D.Raycast(posRightBottom, transform.right, offset, layerObstacles);

            #region Debug

            Debug.DrawRay(posLeftTop, -transform.right * offset, Color.yellow);
            Debug.DrawRay(posLeftBotton, -transform.right * offset, Color.yellow);
            Debug.DrawRay(posRightTop, transform.right * offset, Color.yellow);
            Debug.DrawRay(posRightBottom, transform.right * offset, Color.yellow);

            #endregion

            // Add left side
            if (!raysSideLeft_Top[0] && !raysSideLeft_Top[1])
                listDirectCanMove.Add(TypeMove.Left);

            // Add right side
            if (!raysSideRight_Bottom[0] && !raysSideRight_Bottom[1])
                listDirectCanMove.Add(TypeMove.Right);
        }
        else
        {
            Vector3 posTopRight = transform.position + new Vector3(sizeObject - offset, sizeObject + offset);
            Vector3 posTopLeft = transform.position + new Vector3(-sizeObject + offset, sizeObject + offset);
            Vector3 posBottomRight = transform.position + new Vector3(sizeObject - offset, -sizeObject - offset);
            Vector3 posBottomLeft = transform.position + new Vector3(-sizeObject + offset, -sizeObject - offset);

            raysSideLeft_Top[0] = Physics2D.Raycast(posTopLeft, transform.up, offset, layerObstacles);
            raysSideLeft_Top[1] = Physics2D.Raycast(posTopRight, transform.up, offset, layerObstacles);
            raysSideRight_Bottom[0] = Physics2D.Raycast(posBottomLeft, -transform.up, offset, layerObstacles);
            raysSideRight_Bottom[1] = Physics2D.Raycast(posBottomRight, -transform.up, offset, layerObstacles);

            #region Debug

            Debug.DrawRay(posTopLeft, transform.up * offset, Color.yellow);
            Debug.DrawRay(posTopRight, transform.up * offset, Color.yellow);
            Debug.DrawRay(posBottomLeft, -transform.up * offset, Color.yellow);
            Debug.DrawRay(posBottomRight, -transform.up * offset, Color.yellow);

            #endregion
            // Add forward side
            if (!raysSideLeft_Top[0] && !raysSideLeft_Top[1])
                listDirectCanMove.Add(TypeMove.Forward);

            // Add backward sie
            if (!raysSideRight_Bottom[0] && !raysSideRight_Bottom[1])
                listDirectCanMove.Add(TypeMove.Backward);
        }
    }

    void MakeDecision(bool hitWall = false)
    {
        lastTimeMakeDecision = Time.time;

        // if hit wall, tank can not move with current direct
        if (!hitWall)
        {
            listDirectCanMove.Add(currentDirectMove);
        }

        int rand = Random.Range(0, 2);

        if (rand == 1 || hitWall)
        {

            // Find opponent direct with current direct to add to list direct can move
            switch (currentDirectMove)
            {
                case TypeMove.Forward:
                    listDirectCanMove.Add(TypeMove.Backward);
                    break;
                case TypeMove.Backward:
                    listDirectCanMove.Add(TypeMove.Forward);
                    break;
                case TypeMove.Left:
                    listDirectCanMove.Add(TypeMove.Right);
                    break;
                case TypeMove.Right:
                    listDirectCanMove.Add(TypeMove.Left);
                    break;
            }
        }

        // Random direct in range list direct can move
        currentDirectMove = listDirectCanMove[Random.Range(0, listDirectCanMove.Count)];
    }

    // Method to control direct tank AI move
    void AIMove(TypeMove typeMove)
    {
        switch (typeMove)
        {
            case TypeMove.Backward:
                aiController.MoveDown();
                break;
            case TypeMove.Forward:
                aiController.MoveUp();
                break;
            case TypeMove.Left:
                aiController.MoveLeft();
                break;
            case TypeMove.Right:
                aiController.MoveRight();
                break;
            case TypeMove.None:
                aiController.Release();
                break;
        }
    }

    //--METHOD STOP MOVE AI--//
    public void StopMove()
    {
        isStop = true;
        aiController.Release();
    }

    //--METHOD STOP MOVE AI WITH EFFECT FREEZING--//
    public void StopMoveBySkill()
    {
        isStop = true;
        aiController.Release();

        FX_Freezing.gameObject.SetActive(true);
        if (!FX_Freezing.isPlaying)
            FX_Freezing.Play();
    }

    //--METHOD RESUME MOVE--//
    public void ContinueMove()
    {
        isStop = false;

        lastTimeMakeDecision = Time.time;
        lastTimeShot = Time.time;

        FX_Freezing.gameObject.SetActive(false);
    }

    //--METHOD STOP EFFECT FREEZING--//
    public void StopEffectFreezing()
    {
        FX_Freezing.Stop();
        FX_Freezing.gameObject.SetActive(false);
    }

    void OnDisable()
    {
        isStop = false;

        FX_Freezing.gameObject.SetActive(false);
    }

}
