﻿using UnityEngine;
using System.Collections;

public enum TypeEnemy
{
    Normal,
    Special,
    Items
}
public class TankEnemy : TankObject {

    public GameObject shieldObj;
    public GameObject FX_Shield_Explosion;
    public TypeEnemy typeEnemy = TypeEnemy.Normal;
    public int Score = 10;

    private PersistentDataGameController persistentData;

    void Awake()
    {
        persistentData = FindObjectOfType<PersistentDataGameController>();
    }

    public override int currentArmor
    {
        set
        {
            if (value < _currentHealth)
                SoundManager.Instance.PlaySound(soundfx_getHit);
            _currentArmor = Mathf.Clamp(value, 0, int.MaxValue);  

            if (shieldObj)
            {
                if (_currentArmor == 0)
                {
                    var obj = SmartPool.Spawn(FX_Shield_Explosion, transform.position, Quaternion.identity);
                    obj.transform.SetParent(this.gameObject.transform);
                    obj.GetComponent<FX_Deactive>().timeDeactive = 2.0f;

                    shieldObj.SetActive(false);
                }
            }
        }
    }

    public override int currentHealth
    {
        set
        {
            if (value < _currentHealth && value != 0)
                SoundManager.Instance.PlaySound(soundfx_getHit);

            _currentHealth = Mathf.Clamp(value, 0, MaxHealth);

            base.currentHealth = value;

            if (_currentHealth == 0) {
                if (typeEnemy == TypeEnemy.Normal)
                {
                    EventManager.Instance.PostNotification(EVENT_TYPE.ENEMY_DEAD, this);              // Post event enemy dead
                    persistentData.currentScore += Score;
                }
                else
                {
                    EventManager.Instance.PostNotification(EVENT_TYPE.ENEMY_SPECIAL_DEAD, this);      // Post event specila enemy dead   
                    typeEnemy = TypeEnemy.Normal;
                    persistentData.currentScore += Score*2;
                }

                // Spawn effect explosion
                if (FX_Explosion)
                    SmartPool.Spawn(FX_Explosion, transform.position, Quaternion.identity);

                SmartPool.Despawn(this.gameObject);
            }
        }
    }

    public void SetSpecialEnemy()
    {
        typeEnemy = TypeEnemy.Special;
    }
    //--METHOD ACTIVE SHIELD FROM OUTSIDE CLASS--//
    public void ActiveShield(int armor = int.MaxValue)
    {
        shieldObj.SetActive(true);
        _currentArmor = armor;
    }

    //--METHOD RESET--//
    public override void Reset()
    {
        _currentArmor = 0;
        shieldObj.SetActive(false);
    }

    //--RESET TYPE ENEMY--//
    void OnDisable()
    {
        if (typeEnemy == TypeEnemy.Special)
            typeEnemy = TypeEnemy.Normal;
    }
}
