﻿using UnityEngine;
using System.Collections;

public class TankPlayer : TankObject {
    public float startFireRate;
    public ShieldPlayer shieldPlayer;

    public GameObject FX_DownLevel;

    public BodyActive[] bodyTankLevels;                             // List sprite base on level
    public GameObject[] wheelLevels;                                // Wheel object base on level
    public GameObject[] bulletLevels;

    private TankCannonController cannon;
    private TankDestrollerController tankDestroller;
    private ControllerInput tankControlSpeed;

    #region property
    public int currentLevel
    {
        get { return _currentLevel; }
        set
        {
            int level = Mathf.Clamp(value, 1, 3);                   // Limited lv 3

            if (level > _currentLevel)
                LevelUp();
            else if (level < _currentLevel)
                LevelDown();

            _currentLevel = level;                           
        }
    }

    private int _currentLevel = 1;

    public override int currentHealth
    {
        set
        {
            if (value < _currentHealth && value != 0)
                SoundManager.Instance.PlaySound(soundfx_getHit);

            _currentHealth = Mathf.Clamp(value, 0, MaxHealth);

            base.currentHealth = value;

            if (_currentHealth == 0)
            {
                if (currentLevel == 1)
                {
                    EventManager.Instance.PostNotification(EVENT_TYPE.PLAYER_DEAD, this);              // Poste event player dead

                    // Spawn effect explosion
                    if (FX_Explosion)
                        SmartPool.Spawn(FX_Explosion, transform.position, Quaternion.identity);

                    SmartPool.Despawn(this.gameObject);
                }
                else
                    currentLevel--;
            }
        }
    }
    #endregion

    void Start()
    {
        EventManager.Instance.AddListener(EVENT_TYPE.PLAYER_BASE_DEAD, this);

        cannon = GetComponent<TankCannonController>();
        tankDestroller = GetComponent<TankDestrollerController>();
        tankControlSpeed = GetComponent<ControllerInput>();

        cannon.fireRate = startFireRate;
    }

    //--EVENT GAME--//
    public override void OnEvent(EVENT_TYPE Event_Type, Component Sender, object Param = null)
    {
        if (Event_Type == EVENT_TYPE.PLAYER_BASE_DEAD)
            ResetLevelPlayer();
    }

    //--METHOD RESET LEVEL TO DEFAULT TANK PLAYER--//
    public void ResetLevelPlayer()
    {
        // Reset default level
        MaxHealth = 1;
        cannon.fireRate = startFireRate;
        _currentLevel = 1;
        cannon.prefabsBullet = bulletLevels[0];
        tankControlSpeed.ModifyMaxSpeed = -1.0f;

        // Deactive destroy tree object
        if ((tankDestroller.layerDestroy.value & (1 << 13)) > 0)
            tankDestroller.layerDestroy -= (int)Mathf.Pow(2, 13);

        ResetSpriteLevel();

        currentHealth = 0;
    }

    //--METHOD CALL LEVEL UP--//
    public void LevelUp()
    {
        ActiveShield(0.5f);

        MaxHealth += 1;
        _currentHealth = MaxHealth;
        cannon.fireRate -= 0.2f;

        bodyTankLevels[_currentLevel].gameObject.SetActive(true);
        bodyTankLevels[_currentLevel].Active();
        bodyTankLevels[_currentLevel - 1].Deactive();

        // Set bullet base on level
        cannon.prefabsBullet = bulletLevels[_currentLevel];

        // Up to level 3, current lv 2
        if (_currentLevel == 2)
        {
            wheelLevels[0].SetActive(false);
            wheelLevels[1].SetActive(true);

            // Active destroy tree object
            tankDestroller.layerDestroy += (int)Mathf.Pow(2, 13);

            tankControlSpeed.ModifyMaxSpeed = 2.0f;
        }
        else if (_currentLevel == 1)
            tankControlSpeed.ModifyMaxSpeed = 2.6f;

    }

    //--METHOD CALL LEVEL DOWN--//
    public void LevelDown()
    {
        MaxHealth -= 1;
        _currentHealth = MaxHealth;
        cannon.fireRate += 0.2f;

        // Spawn FX
        GameObject fx =  SmartPool.Spawn(FX_DownLevel, transform.position, Quaternion.identity);
        fx.transform.SetParent(this.transform);

        bodyTankLevels[_currentLevel - 1].Deactive();
        bodyTankLevels[_currentLevel-2].gameObject.SetActive(true);

        // Set bullet base on level
        cannon.prefabsBullet = bulletLevels[_currentLevel - 2];

        if (_currentLevel == 3)
        {
            wheelLevels[0].SetActive(true);
            wheelLevels[1].SetActive(false);

            // Deactive destroy tree object
            tankDestroller.layerDestroy -= (int)Mathf.Pow(2, 13);

            tankControlSpeed.ModifyMaxSpeed = 2.6f;
        }
        else if (_currentLevel == 2)
            tankControlSpeed.ModifyMaxSpeed = -1.0f;                // Reset default speed
    }

    //--METHOD RESET SPRITE LEVEL--//
    void ResetSpriteLevel()
    {
        bodyTankLevels[0].gameObject.SetActive(true);
        bodyTankLevels[1].gameObject.SetActive(false);
        bodyTankLevels[2].gameObject.SetActive(false);

        wheelLevels[0].SetActive(true);
        wheelLevels[1].SetActive(false);
    }

    //--METHOD ACTIVE SHIELD FOR PLAYER--//
    public void ActiveShield(float timeLive)
    {
        shieldPlayer.gameObject.SetActive(true);
        shieldPlayer.IntialShield();
        shieldPlayer.timeAlive = timeLive;
    }

    //--SET STATIC DIRECT TANK WHEN SAPWN--//
    void OnEnable()
    {
        GetComponentInChildren<SpriteRenderer>().transform.eulerAngles = new Vector3(0, 0, 0);
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.K))
            currentLevel++;

        if (Input.GetKeyDown(KeyCode.L))
            currentLevel--;

        if (Input.GetKeyDown(KeyCode.Q))
        {
            ActiveShield(100.0f);
        }
    }


}
