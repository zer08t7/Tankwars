﻿using UnityEngine;
using System.Collections;

public class BulletPlayer : Bullet {

    public override void OnTriggerEnter2D(Collider2D other)
    {
        // If hit self
        if (other.gameObject.tag == "Player" || other.gameObject.tag == "Shield")
            return;

        if (explosionPrefabs)
            SmartPool.Spawn(explosionPrefabs,transform.position,Quaternion.identity);

        if (other.gameObject.tag != "Enemy")
             base.OnTriggerEnter2D(other);
        else
        {
            var tankObj = other.GetComponent<TankObject>();

            if (tankObj.currentArmor > 0)
                tankObj.currentArmor--;
            else
                tankObj.currentHealth--;

            SmartPool.Despawn(this.gameObject);
        }
    }
}
