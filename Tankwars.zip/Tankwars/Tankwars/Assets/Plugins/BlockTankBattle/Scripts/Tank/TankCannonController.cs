﻿using UnityEngine;
using System.Collections;

/// <summary>
/// Script control shot tank
/// </summary>

public class TankCannonController : MonoBehaviour {

	public Transform positionCanon;
	public GameObject prefabsBullet;
	public float fireRate = 0.25f;

    public Transform bodyShot;
    public GameObject effectShot;
    public float shockSpeed = 2.5f;                                         // Shock speed
    public float shock = 0.5f;                                              // Shock cannon

    public AudioSource audioSource;
   // public AudioClip soundShot;                                           // can use if each bullet have different sound effect

	private float lastTimeShot;
    private float posBodyShot;

    private SpriteRenderer sprBodyTank;
    private ControllerInput controller;
    private bool isShooting;

	void Awake()
	{
		sprBodyTank = GetComponentInChildren<SpriteRenderer> ();
        controller = GetComponent<ControllerInput>();
    }

    void OnEnable()
    {
        isShooting = false;
    }

    void Start()
    {
        posBodyShot = bodyShot.localPosition.y;
    }

    void Update()
    {
        if (isShooting)
            Shot();
    }

    // Method call shot
    public void Shot()
	{
		if( (Time.time - lastTimeShot)> fireRate ) {
			TankShot ();
			lastTimeShot = Time.time;
		}
	}

    public void EnterShot()
    {
        isShooting = true;
    }

    public void CancelShot()
    {
        isShooting = false;
    }

	private void TankShot()
	{
        controller.ModifyMaxSpeed = 0.0f;
        bodyShot.localPosition = new Vector3(bodyShot.localPosition.x, posBodyShot);
        StartCoroutine(BodyShot());
	}

    private IEnumerator BodyShot()
    {
        float _y = bodyShot.localPosition.y;
        _y -= shock;

        while(bodyShot.localPosition.y > _y+0.02f)
        {
            bodyShot.localPosition = Vector3.MoveTowards(bodyShot.localPosition, new Vector3(bodyShot.localPosition.x, _y), Time.deltaTime * shockSpeed);
            yield return null;
        }

        if(effectShot)
            effectShot.SetActive(true);

        GameObject bullet = (GameObject)SmartPool.Spawn(prefabsBullet, positionCanon.position, sprBodyTank.transform.rotation);
        bullet.GetComponent<BulletController>().IntialBullet(this.gameObject);

        SoundManager.Instance.PlaySound(audioSource);

        _y += shock;
        while (bodyShot.localPosition.y < _y-0.02f)
        {
            bodyShot.localPosition = Vector3.MoveTowards(bodyShot.localPosition, new Vector3(bodyShot.localPosition.x, _y), Time.deltaTime * shockSpeed * 4.0f);
            yield return null;
        }

        controller.ModifyMaxSpeed = -1f;
    }
}
