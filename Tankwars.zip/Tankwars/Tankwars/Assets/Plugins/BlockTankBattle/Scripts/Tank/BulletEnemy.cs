﻿using UnityEngine;
using System.Collections;

public class BulletEnemy : Bullet {

    public override void OnTriggerEnter2D(Collider2D other)
    {
        if(other.gameObject.tag == "Shield")
        {
            SmartPool.Spawn(explosionPrefabs, transform.position, Quaternion.identity);
            SmartPool.Despawn(this.gameObject);
            return;
        }

        if (other.gameObject.tag == "Enemy")
        {
            // Prevent shot to self 
            if (other.gameObject.GetInstanceID() != objectBelong.GetInstanceID())
            {
                if (explosionPrefabs)
                    SmartPool.Spawn(explosionPrefabs, transform.position, Quaternion.identity);
                SmartPool.Despawn(this.gameObject);
            }
            return;
        }

        if (explosionPrefabs)
            SmartPool.Spawn(explosionPrefabs, transform.position, Quaternion.identity);

        if (other.gameObject.tag != "Player")
            base.OnTriggerEnter2D(other);
        else {
            var tankObj = other.GetComponent<TankObject>();

            if (tankObj.currentArmor > 0)
                tankObj.currentArmor--;
            else
                tankObj.currentHealth--;

            SmartPool.Despawn(this.gameObject);
        }
    }
}
