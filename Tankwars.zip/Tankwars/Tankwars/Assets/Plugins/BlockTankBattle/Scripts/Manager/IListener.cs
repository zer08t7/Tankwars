﻿using UnityEngine;
using System.Collections;
//-----------------------------------------------------------
//Enum defining all possible game events
//More events should be added to the list
public enum EVENT_TYPE {GAME_INIT, 
						GAME_END,
                        GAME_OVER,
						ENEMY_DEAD,
                        ENEMY_SPECIAL_DEAD,
                        PLAYER_BASE_DEAD,
						PLAYER_DEAD,
                        BASE_ENEMY_SPAWNED,
                        ENEMY_BASE_DESTROY,
                        ITEM_SPAWN,
                        ITEM_ACTIVE,
                        NUCLE_ACTIVE,
                        ARMOR_ACTIVE,
                        HEALTH_ACTIVE,
                        PROTECT_BASE_ACTIVE,
                        SCREEN_UI_ACTIVE_FNISH,
                        SCREEN_UI_DEACTIVE_FINISH,
                        ITEMS_CAR_SPAWN,
                        ENEMY_SPECIAL_SPAWN
                        };
//-----------------------------------------------------------
//Listener interface to be implemented on Listener classes
public interface IListener
{
	//Notification function to be invoked on Listeners when events happen
	void OnEvent(EVENT_TYPE Event_Type, Component Sender, object Param = null);
}
//-----------------------------------------------------------