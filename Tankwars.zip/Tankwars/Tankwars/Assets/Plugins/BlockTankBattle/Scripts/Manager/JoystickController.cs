﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class JoystickController : MonoBehaviour,IPointerUpHandler,IPointerDownHandler {

	public ControllerInput tankPlayer;
    public float offset = 35.0f;

	public Sprite button_not_touch;
	public Sprite button_touch;

	public Image[] imageButtons;

	private bool isTouch;
	private Vector3 deltaVector;

	void Update()
	{
		// When touch, process touch postion
		if (isTouch) {

            // Check touch, if have mutiple touch
            Touch[] myTouchs = Input.touches;
            Vector3 touchPos = Vector3.zero;

            if (myTouchs.Length > 1)
            {
                for (int i = 0; i < myTouchs.Length; i++)
                {
                    if (myTouchs[i].position.y < transform.position.y * 2 && myTouchs[i].position.x < transform.position.x * 2)
                    {
                        touchPos = myTouchs[i].position;
                        break;
                    }
                }
                deltaVector = touchPos - transform.position;
            }
            else
                deltaVector = (Vector3)Input.GetTouch(0).position - transform.position;

            // Process when magnitude delta vector greater than 25
            if (Vector3.Magnitude (deltaVector) > 25.0f) {
				if (Mathf.Abs (deltaVector.x) > Mathf.Abs (deltaVector.y)) {
					// Move horizontal
					if (deltaVector.x > offset) {
						tankPlayer.MoveRight ();
						ButtonHit (3);
					} else if (deltaVector.x < -offset) {
						tankPlayer.MoveLeft ();
						ButtonHit (1);
					}
				} else {
					// Move vertical
					if (deltaVector.y > offset) {
						tankPlayer.MoveUp ();
						ButtonHit (0);
					} else if (deltaVector.y < -offset) {
						tankPlayer.MoveDown ();
						ButtonHit (2);
					}
				}
			} else
				tankPlayer.Release ();
		} else
			tankPlayer.Release ();
	}

	// Method to change button sprites
	void ButtonHit(int indexTouch)
	{
		foreach(Image image in imageButtons)
			image.sprite = button_not_touch;
	

		imageButtons[indexTouch].sprite = button_touch;
	}

	// Event handle when touch to joystick
	public void OnPointerUp(PointerEventData eventData )
	{

		foreach(Image image in imageButtons)
			image.sprite = button_not_touch;

		isTouch = false;
	}

	// Event handle when touch to joystick
	public void OnPointerDown(PointerEventData eventData)
	{
		isTouch = true;
	}

    void OnDisable()
    {
        tankPlayer.Release();
    }
}
