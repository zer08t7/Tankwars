﻿using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;

[Serializable]
public enum TypeItems
{
    Nucle,
    LevelUp,
    Freezing,
    Repair,
    Hearth,
    Shield
}

[Serializable]
public struct DataSpawnItems
{
    public TypeItems typeItem;                                              // Type items
    public GameObject prefabObj;                                            // Prefab will sapwn

    [Range(1, 10)]                                                          
    public int weight;                                                      // Use for precentage sapwn

    public float valueItems;                                                // Value effect from iterms
}

public class ItemsManager : MonoBehaviour,IListener {

    public List<DataSpawnItems> itemList;
    public TankPlayer player;

    private List<GameObject> listRandomPickup;
    private List<BaseEnemy> baseEnemyList = new List<BaseEnemy>();

    //--EVENT : CALL WHEN ENEMY ITEM HAVE BEEN DESTROYED--//
    public void OnEvent(EVENT_TYPE Event_Type, Component Sender, object Param = null)
    {
        switch (Event_Type)
        {
            case EVENT_TYPE.ITEM_SPAWN:
                GameObject itemWillSpawn = listRandomPickup[UnityEngine.Random.Range(0, listRandomPickup.Count)];
                SmartPool.Spawn(itemWillSpawn, Sender.gameObject.transform.position, Quaternion.identity);
                break;
            case EVENT_TYPE.BASE_ENEMY_SPAWNED:
                baseEnemyList.Add(Sender.GetComponent<BaseEnemy>());
                break;
            case EVENT_TYPE.ITEM_ACTIVE:
                ActiveSkill(Sender.GetComponent<Item>().typeItem);
                break;
        }
    }

    void Start()
    {
        EventManager.Instance.AddListener(EVENT_TYPE.ITEM_SPAWN, this);
        EventManager.Instance.AddListener(EVENT_TYPE.BASE_ENEMY_SPAWNED, this);
        EventManager.Instance.AddListener(EVENT_TYPE.ITEM_ACTIVE, this);

        StateManager.Instance.OnStageGameEnd += Reset;

        // Make list random pickup with weight
        listRandomPickup = new List<GameObject>();

        foreach (DataSpawnItems item in itemList)
        {
            for (int i = 0; i < item.weight; i++)
                listRandomPickup.Add(item.prefabObj);
        }
    }

    //--INPLEMENT BAHAVOIRS ITEMS--//
    void ActiveSkill(TypeItems typeItem)
    {
        DataSpawnItems itemActive = FindItems(typeItem).Value;

        switch(typeItem)
        {
            case TypeItems.Nucle:
                foreach (BaseEnemy _base in baseEnemyList)
                    _base.ExplosionNuCleItemPickup();
                break;
            case TypeItems.Freezing:
                foreach (BaseEnemy _base in baseEnemyList)
                    _base.FreezingEnemyItemPickup(itemActive.valueItems);
                break;
            case TypeItems.Hearth:
                FindObjectOfType<BasePlayer>().current_base_health++;
                break;
            case TypeItems.LevelUp:
                player.currentLevel++;
                break;
            case TypeItems.Repair:
                FindObjectOfType<BasePlayer>().ActiveBlockWall(itemActive.valueItems);
                break;
            case TypeItems.Shield:
                player.ActiveShield(itemActive.valueItems);
                break;
        }
    }

    //--METHOD TO FIND DATA ITEM FORM TYPE ITEM--//
    DataSpawnItems ? FindItems(TypeItems typeItem)
    {
        foreach(DataSpawnItems data in itemList)
        {
            if (data.typeItem == typeItem)
                return data;
        }

        Debug.LogError("Can not find items!");

        return null;
    }

    //--RESET WHEN END GAME--//
    void Reset()
    {
        baseEnemyList.Clear();

        // Deactive all item
        var items = FindObjectsOfType<Item>();
        foreach (Item item in items)
            SmartPool.Despawn(item.gameObject);
    }
}
