﻿using UnityEngine;
using System.Collections;

public enum GAME_STATE
{
    Loading,
    Home,
    GameStart,
    GameOver,
    GameEnd
}

public delegate void OnStateChangeHandler();
public class StateManager : MonoBehaviour {

    public event OnStateChangeHandler
        OnStateGameLoading,
        OnStateGameStart,
        OnStageGameEnd,
        OnStateGameHome;

    public GAME_STATE gameState { get; private set; }

    private static StateManager instance = null;

    public static StateManager Instance
    {
        get
        {
            if (instance == null)
            {
                DontDestroyOnLoad(StateManager.instance);
                instance = new GameObject("StateManager").AddComponent<StateManager>();
            }
            return instance;
        }
    }

    public void SetStateGame(GAME_STATE gameState)
    {
        this.gameState = gameState;

        switch (gameState)
        {
            case GAME_STATE.Loading:
                OnStateGameLoading();
                break;
            case GAME_STATE.GameOver:
                OnStageGameEnd();
                break;
            case GAME_STATE.GameEnd:
                OnStageGameEnd();
                break;
            case GAME_STATE.GameStart:
                OnStateGameStart();
                break;
            case GAME_STATE.Home:
                OnStateGameHome();
                break;
        }
    }

}
