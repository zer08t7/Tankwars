﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;
using System;

//--MAIN CLASS FOR CONTROL GAME--//
public class GameController : MonoBehaviour,IListener {
	public static int currentLevel{ get; private set;}
    public const float SIZE_OBJECT = 0.5f;

    private MapDataController mapdata;
    private StateManager stateGameManager;
    private PersistentDataGameController persistentData;
    private UIManager uiManager;
    private bool isEndGame;

    void Awake() {
        mapdata = GetComponent<MapDataController>();
        persistentData = GetComponent<PersistentDataGameController>();
        uiManager = FindObjectOfType<UIManager>();
        isEndGame = false;

        // First load level 1 map
        mapdata.SaveAssetTextToPersistentData();
        stateGameManager = StateManager.Instance;
    }

    void Start()
	{
        EventManager.Instance.AddListener(EVENT_TYPE.GAME_OVER, this);
        EventManager.Instance.AddListener(EVENT_TYPE.SCREEN_UI_ACTIVE_FNISH, this);
        EventManager.Instance.AddListener(EVENT_TYPE.SCREEN_UI_DEACTIVE_FINISH, this);
        EventManager.Instance.AddListener(EVENT_TYPE.ENEMY_BASE_DESTROY, this);

        // Intial loading
        stateGameManager.SetStateGame(GAME_STATE.Loading);
        ///StartCoroutine(WaitLoad());
    }

    IEnumerator WaitLoad()
    {
        yield return new WaitForSeconds(2.0f);
        //stateGameManager.SetStateGame(GameState.Loading);
        LoadLevel(1);
    }

    // Method call when restart level
    public void RestartLevel()
    {
        // Reset map
        mapdata.DeactiveAllMap();
        mapdata.ActiveMap(currentLevel);
        persistentData.ResetScore();
    }

    //--METHOD WAIT SMALL TIME TO ACTIVE START LEVEL THAT ENSURE LEVELED IN SENCE--//
    IEnumerator LevelStart()
    {
        yield return new WaitForSeconds(.1f);

        StateManager.Instance.SetStateGame(GAME_STATE.GameStart);
    }

    //--METHOD CALL TO RESET ALL DATA PLAYER--//
    public void ResetDataWhenPlayerSkipLevel()
    {
        BasePlayer basePlayer = FindObjectOfType<BasePlayer>();
        basePlayer.ExplosionBase();
        basePlayer.Reset();
        persistentData.ResetScore(); 
    }

    //--METHOD CALL LOAD NEW LEVEL--//
    public void LoadLevel(int level)
    {
        if (currentLevel == level)
            RestartLevel();
        else
        {
            // Unload old sence
            if (currentLevel < 10)
                SceneManager.UnloadScene("Level0" + currentLevel.ToString());
            else
                SceneManager.UnloadScene("Level" + currentLevel.ToString());

            currentLevel = level;   

            if (level < 10)
                SceneManager.LoadScene("Level0" + level.ToString(), LoadSceneMode.Additive);
            else
                SceneManager.LoadScene("Level" + level.ToString(), LoadSceneMode.Additive);

            // Load data 
            mapdata.LoadDataJson(level);

            // Reset map
            mapdata.DeactiveAllMap();
            mapdata.ActiveMap(currentLevel);      
        }
    }

    void CheckWinGame(BaseEnemy baseSender)
    {
        var baseEnemys = FindObjectsOfType<BaseEnemy>();

        foreach (BaseEnemy _base in baseEnemys)
        {           
            if (baseSender.gameObject.GetInstanceID() == _base.gameObject.GetInstanceID())
                continue;
            if (!_base.isBaseDead)
                return;
        }

        isEndGame = true;

        StartCoroutine(WaitActiveGameWin());
       
    }

    //--EVENT GAME PROCESS--//

    public void OnEvent(EVENT_TYPE Event_Type, Component Sender, object Param = null)
    {
        switch (Event_Type)
        {
            case EVENT_TYPE.SCREEN_UI_ACTIVE_FNISH:
                if (StateManager.Instance.gameState == GAME_STATE.Loading)
                {
                    StateManager.Instance.SetStateGame(GAME_STATE.Home);
                    SoundManager.Instance.PlayBackgroundMusic();
                }
                break;
            case EVENT_TYPE.SCREEN_UI_DEACTIVE_FINISH:
                isEndGame = false;
                StartCoroutine(LevelStart());
                break;
            case EVENT_TYPE.ENEMY_BASE_DESTROY:
                if (!isEndGame)
                    CheckWinGame((BaseEnemy) Sender);
                break;
            case EVENT_TYPE.GAME_OVER:
                if (!isEndGame)
                {
                    isEndGame = true;
                    StartCoroutine(WaitActiveGameOver());
                }
                break;
        }
    }

    //--METHOD CALL ACTIVE UI END GAME AFTER 3.5 SECONDS--//
    IEnumerator WaitActiveGameWin()
    {
        yield return new WaitForSeconds(3.5f);
        uiManager.VictoryUIActive();
    }

    //--METHOD CALL ACTIVE UI GAMEOVER AFTER 2.0 SECONDS--//
    IEnumerator WaitActiveGameOver()
    {
        yield return new WaitForSeconds(2.0f);
        uiManager.DefeatUIActive();
    }
}
