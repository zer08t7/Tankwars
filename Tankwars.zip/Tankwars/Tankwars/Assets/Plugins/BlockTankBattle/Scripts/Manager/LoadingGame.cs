﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

//--THIS SCRIPT INTIAL FOR GAME--//
public class LoadingGame : MonoBehaviour {

    public Transform fakeLoadingSprite;
    public Text textUiLoading;
    public float speedLoading = 1.0f;

    private UIBackgroundController uiBackground;

    void Awake()
    {
        uiBackground = FindObjectOfType<UIBackgroundController>();
        StateManager.Instance.OnStateGameLoading += Loading;
        fakeLoadingSprite.localScale = new Vector3(0, 1);
    }

    void Loading()
    {
        textUiLoading.transform.parent.gameObject.SetActive(true);
        StartCoroutine(StartLoadingEffect());
        StartCoroutine(EffectLoadingText());
    }

    IEnumerator StartLoadingEffect()
    {
        while(fakeLoadingSprite.localScale.x < 0.99f)
        {
            fakeLoadingSprite.localScale = new Vector3(Mathf.Lerp(fakeLoadingSprite.localScale.x, 1.0f, Time.deltaTime * speedLoading), 1);
            yield return null;
        }

        fakeLoadingSprite.localScale = new Vector3(1, 1);
        uiBackground.ActiveScreenUI();
        fakeLoadingSprite.parent.parent.gameObject.SetActive(false);
        StartCoroutine(LoadingTextDisappear());
    }

    IEnumerator EffectLoadingText()
    {
        while(fakeLoadingSprite.localScale.x < 0.99f)
        {
            textUiLoading.text = "Loading.";
            yield return new WaitForSeconds(0.5f);
            textUiLoading.text = "Loading..";
            yield return new WaitForSeconds(0.5f);
            textUiLoading.text = "Loading...";
            yield return new WaitForSeconds(0.5f);
        }
    }

    IEnumerator LoadingTextDisappear()
    {
        while(textUiLoading.color.a > 0.02f)
        {
            textUiLoading.color = new Color(1, 1, 1, Mathf.MoveTowards(textUiLoading.color.a, 0, Time.deltaTime * 2.0f));
            yield return null;
        }

        textUiLoading.transform.parent.gameObject.SetActive(false);
        gameObject.SetActive(false);
    }

    void OnDisable()
    {
        StateManager.Instance.OnStateGameLoading -= Loading;
    }

}
