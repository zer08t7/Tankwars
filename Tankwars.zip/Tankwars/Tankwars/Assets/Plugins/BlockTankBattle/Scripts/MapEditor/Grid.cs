﻿using UnityEngine;
using System.Collections;

public class Grid : MonoBehaviour
{
    public Vector3 startPostion;
    public float gridSize = 0.5f;
    public Color color = Color.red;
    public TileSet tileSet;
    public bool canMoveObject;
    public int numberGridWidth = 60;
    public int numberGridHeight = 30;
    public Transform tilePrefab;

    public void OnDrawGizmos()
    {
        // Draw grid with gizmos
        Gizmos.color = color;
        for (int y = 0; y <= numberGridHeight; y++)
            Gizmos.DrawLine(new Vector3(startPostion.x - gridSize * numberGridWidth / 2, startPostion.y - gridSize * numberGridHeight / 2 + y * gridSize), new Vector3(startPostion.x + gridSize * numberGridWidth / 2, startPostion.y - gridSize * numberGridHeight / 2 + y * gridSize));
        for (int x = 0; x <= numberGridWidth; x++)
            Gizmos.DrawLine(new Vector3(startPostion.x - gridSize * numberGridWidth / 2 + x * gridSize, startPostion.y - gridSize * numberGridHeight / 2), new Vector3(startPostion.x - gridSize * numberGridWidth / 2 + x * gridSize, startPostion.y + gridSize * numberGridHeight / 2));
    }

}
