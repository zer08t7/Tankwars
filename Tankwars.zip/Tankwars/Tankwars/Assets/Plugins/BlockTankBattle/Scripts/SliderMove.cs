﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System;

public class SliderMove : MonoBehaviour
{
    private float offset = 120.0f;

    private bool isChecking;
    private float delSpeed = 0.0f;
    private float delMove;

    private float limitBottom;
    private float limitAbove;

    private GridLayoutGroup gridLayout;
    private int numberMapEachLine;

    void Awake()
    {
        limitBottom = transform.localPosition.y - offset;

        gridLayout = GetComponent<GridLayoutGroup>();

        float wildth = GetComponent<RectTransform>().rect.width;

        float currentWildth = gridLayout.cellSize.x;

        int numberMapEachLine = 1;
        while (true)
        {
            currentWildth += ( gridLayout.cellSize.x + gridLayout.spacing.x);
            if (currentWildth > wildth)
                break;
            else
                numberMapEachLine++;
        }

        int numberStage = transform.childCount;
        int numberLine = (int)(numberStage / numberMapEachLine);

        if (numberLine * numberMapEachLine < numberStage)
            numberLine++;

        Vector3 currentRect = transform.GetComponent<RectTransform>().localPosition;

        limitAbove = currentRect.y + (numberLine - 3) * gridLayout.cellSize.y + (numberLine - 3) * gridLayout.spacing.y + offset;
    }

    void Update()
    {
        delMove = 0.0f;
        if(Input.touchCount > 0)
            delMove = Input.touches[0].deltaPosition.y;

        if (Mathf.Abs(delMove) > 3.0f)
        {
            delSpeed = (Mathf.Sign(delMove * delSpeed) > 0) ? delSpeed : 0.0f;
            delSpeed = Mathf.MoveTowards(delSpeed, 600.0f * Mathf.Sign(delMove), Time.deltaTime * 800.0f * Mathf.Abs(delMove));
            delSpeed = Mathf.Clamp(delSpeed, -600.0f, 600.0f);
        }
        else
            delSpeed = Mathf.MoveTowards(delSpeed, 0.0f, Time.deltaTime * 720.0f);

        if(Input.touchCount > 0 || (transform.localPosition.y > limitBottom + offset && transform.localPosition.y < limitAbove - offset))
            transform.localPosition = new Vector3(transform.localPosition.x, Mathf.Clamp(transform.localPosition.y + Time.deltaTime * delSpeed * 2.5f, limitBottom, limitAbove), transform.localPosition.z);

        if(transform.localPosition.y < limitBottom + offset && Input.touchCount == 0)
        {
            transform.localPosition = Vector3.MoveTowards(transform.localPosition, new Vector3(transform.localPosition.x, limitBottom + offset, transform.localPosition.z), Time.deltaTime * 900.0f);
        }

        if (transform.localPosition.y > limitAbove - offset && Input.touchCount == 0)
        {
            transform.localPosition = Vector3.MoveTowards(transform.localPosition, new Vector3(transform.localPosition.x, limitAbove - offset, transform.localPosition.z), Time.deltaTime * 900.0f);
        }
    }
}
