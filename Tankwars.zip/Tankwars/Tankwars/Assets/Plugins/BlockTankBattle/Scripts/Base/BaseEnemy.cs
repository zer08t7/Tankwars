﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

[Serializable]
public struct DataSpawn
{
    public GameObject prefabObj;
    [Range(0,10)]
    public int weight;
}

public class BaseEnemy : BaseController
{
    public List<DataSpawn> listEnemys;                                      // List enemy will spawn

    public int MaxEnemy = 7;                                                // Destroy maxEnemy will change base from block to brick
    public int NumberEnemyEachTurn = 3;                                     // Maintain number enemy in gameplay

    public GameObject FX_Explosion_Nucle;
    public GameObject FX_SpecialEnemy;

    public float percentageToShieldEnemy = 20.0f;
    public bool tutorial;

    private List<GameObject> enemySpawneds;
    private List<GameObject> listRandomPickup;

    private int currentNumberSpawn;
    private IEnumerator coroutineSpawn;

    private bool isFreezing;

    public override void Awake()
    {
        base.Awake();
        enemySpawneds = new List<GameObject>();

        // Make list random pickup with weight
        listRandomPickup = new List<GameObject>();

        // Add enemys to list
        foreach (DataSpawn enemy in listEnemys)
        {
            for (int i = 0; i < enemy.weight; i++)
                listRandomPickup.Add(enemy.prefabObj);
        }

        // Reset layer
        SetBlockBase();

        // Regis event
        EventManager.Instance.AddListener(EVENT_TYPE.ENEMY_DEAD, this);
        EventManager.Instance.AddListener(EVENT_TYPE.ENEMY_SPECIAL_DEAD, this);

        // Regis state game
        StateManager.Instance.OnStageGameEnd += StopSpawnEnemy;
        StateManager.Instance.OnStateGameStart += StartSpawnEnemy;     
    }

    protected override void OnDisable()
    {
        base.OnDisable();
        StateManager.Instance.OnStageGameEnd -= StopSpawnEnemy;
        StateManager.Instance.OnStateGameStart -= StartSpawnEnemy;
    }

    //--METHOD START SPAWN ENEMY WHEN GAME START--//
    void StartSpawnEnemy()
    {
        //print(gameObject.name);
        EventManager.Instance.PostNotification(EVENT_TYPE.BASE_ENEMY_SPAWNED, this);
        coroutineSpawn = FirstSpawnEnemy();
        StartCoroutine(coroutineSpawn);

        // Spawn item for tutorial
        if (tutorial)
            StartCoroutine(WaitForSpawnFirstItemsCar());
    }

    //--METHOD STOP SPAWN ENEMY WHEN GAME OVER--//
    void StopSpawnEnemy()
    {
        StopAllCoroutines();
    }

    //--METHOD SPAWN WHEN START LEVEL--//
    IEnumerator FirstSpawnEnemy()
    {
        for (int i = 0; i < NumberEnemyEachTurn; i++)
            yield return SpawnEnemy();
    }
    //--WHEN TANK ENEMY WILL CALL EVENT THAT THIS METHOD WILL RUN TO SPAWN NEW TANK--//
    IEnumerator SpawnEnemy()
    {
        if (enemySpawneds.Count < NumberEnemyEachTurn)
        {
            yield return new WaitForSeconds(0.5f);
            Transform randPointSpawn = spawnPoints.transform.GetChild(UnityEngine.Random.Range(0, spawnPoints.transform.childCount)); 

            // if base dead can not spawn
            if (!isDead)
                SmartPool.Spawn(FX_Spawn, randPointSpawn.position, Quaternion.identity);

            yield return new WaitForSeconds(1.0f);

            // if base dead can not spawn
            if (!isDead)
            {
                GameObject obj = SmartPool.Spawn(listRandomPickup[UnityEngine.Random.Range(0, listRandomPickup.Count)], randPointSpawn.position, Quaternion.identity);

                InplementBehavious(obj);

                enemySpawneds.Add(obj);
            }
        }

    }

    //--METHOD SPAWN CAR FIRST USE FOR TUTORIAL--//
    IEnumerator WaitForSpawnFirstItemsCar()
    {
        yield return new WaitForSeconds(4.0f);
        Transform randPointSpawn = spawnPoints.transform.GetChild(UnityEngine.Random.Range(0, spawnPoints.transform.childCount));

        SmartPool.Spawn(FX_Spawn, randPointSpawn.position, Quaternion.identity);
        yield return new WaitForSeconds(1.0f);

        GameObject obj = SmartPool.Spawn(listEnemys[listEnemys.Count-1].prefabObj, randPointSpawn.position, Quaternion.identity);
        EventManager.Instance.PostNotification(EVENT_TYPE.ITEMS_CAR_SPAWN, obj.transform);
        enemySpawneds.Add(obj);
    }

    //--METHOD INPLEMENT BEHAVIOUR ENEMY--//
    void InplementBehavious(GameObject obj)
    {
        TankEnemy tankEnemy = obj.GetComponent<TankEnemy>();

        if (tankEnemy)
        {
            float rand = UnityEngine.Random.Range(0, 100);

            if (rand < percentageToShieldEnemy)
                tankEnemy.ActiveShield(2);
            currentNumberSpawn++;

            if (currentNumberSpawn == MaxEnemy)
            {
                tankEnemy.SetSpecialEnemy();
                EventManager.Instance.PostNotification(EVENT_TYPE.ENEMY_SPECIAL_SPAWN, obj.transform);
                var fx = SmartPool.Spawn(FX_SpecialEnemy, obj.transform.position, Quaternion.identity);
                fx.transform.SetParent(obj.transform);
            }
        }

        if (isFreezing)
            obj.GetComponent<TankAIController>().StopMoveBySkill();
    }

    //--RESET METHOD CALL WHEN GAME RESTART--//
    public override void Reset()
    {
        base.Reset();

        isFreezing = false;

        // Deactive all enemy
        foreach (GameObject enemy in enemySpawneds)
            SmartPool.Despawn(enemy);

        enemySpawneds.Clear();
        // StartCoroutine(StartSpawnEnemy());

        // Reset layer
        SetBlockBase();

        currentNumberSpawn = 0;

    }

    #region Public Method

    //--CAL DESTROY BASE--//
    public override void DestroyBase()
    {
        isDead = true;
        CallEnemyDead();
        EventManager.Instance.PostNotification(EVENT_TYPE.ENEMY_BASE_DESTROY, this);
    }

    //--METHOD CALL TO DESTROY ALL CURRENT ENEMY SPAWNED--//
    public void CallEnemyDead()
    {
        GameObject[] enemysWillDead = new GameObject[enemySpawneds.Count];
        enemysWillDead = enemySpawneds.ToArray();

        if (enemysWillDead.Length > 0)
        {
            foreach (GameObject enemy in enemysWillDead)
                enemy.GetComponent<TankObject>().currentHealth = 0;
        }
    }

    //--METHOD CALL NUCLE EXPLOSION ALL ENEMY--//
    public void ExplosionNuCleItemPickup()
    {
        StartCoroutine(SlowMotionExplosion());
    }

    //--METHOD CALL STOP ALL ENEMY--//
    public void FreezingEnemyItemPickup(float timeWait)
    {
        if (!isFreezing)
            StartCoroutine(FrezzingEnemy(timeWait));
    }

    #endregion

    //--METHOD MAKE EFFECT EXPLOSION--//
    IEnumerator SlowMotionExplosion()
    {
        GameObject[] enemysWillDead = new GameObject[enemySpawneds.Count];
        enemysWillDead = enemySpawneds.ToArray();

        // Call when exist enemy in screen
        if (enemysWillDead.Length > 0)
        {

            foreach (GameObject enemy in enemysWillDead)
            {
                enemy.GetComponent<TankAIController>().StopMove();
                SmartPool.Spawn(FX_Explosion_Nucle, enemy.transform.position, Quaternion.identity);
            }

            // Slow motion with time scale
            while (Time.timeScale > 0.2f)
            {
                Time.timeScale -= Time.deltaTime / 0.5f;
                yield return null;
            }

            yield return new WaitForSeconds(0.15f);

            // Call destroy all enemy and reset 
            foreach (GameObject enemy in enemysWillDead)
            {
                enemy.GetComponent<TankAIController>().ContinueMove();
                enemy.GetComponent<TankObject>().currentHealth = 0;
            }

            // Resume time scale
            while (Time.timeScale < 0.98f)
            {
                Time.timeScale += Time.deltaTime / 0.5f;
                yield return null;
            }

            Time.timeScale = 1;
        }
    }

    //--METHOD INPLEMENT STOP ALL ENEMY-//
    IEnumerator FrezzingEnemy(float timeWait)
    {
        isFreezing = true;
        GameObject[] enemysWillDead = new GameObject[enemySpawneds.Count];
        enemysWillDead = enemySpawneds.ToArray();

        // Call when exist enemy in screen
        if (enemysWillDead.Length > 0)
        {
            foreach (GameObject enemy in enemysWillDead)
            {
                enemy.GetComponent<TankAIController>().StopMoveBySkill();
            }
        }

        yield return new WaitForSeconds(timeWait - 1.0f);

        // Effect recover enemy
        enemysWillDead = new GameObject[enemySpawneds.Count];
        enemysWillDead = enemySpawneds.ToArray();

        if (enemysWillDead.Length > 0)
        {
            foreach (GameObject enemy in enemysWillDead)
            {
                enemy.GetComponent<TankAIController>().StopEffectFreezing();
            }
        }

        yield return new WaitForSeconds(1.0f);

        // Resume move enemy
        isFreezing = false;

        foreach (GameObject enemy in enemySpawneds)
            enemy.GetComponent<TankAIController>().ContinueMove();
    }

    //--EVENT--//
    public override void OnEvent(EVENT_TYPE Event_Type, Component Sender, object Param = null)
    {
        // check enemy belong to base ?
        if (enemySpawneds.Contains(Sender.gameObject))
        {
            enemySpawneds.Remove(Sender.gameObject);
            if (!isDead) 
                StartCoroutine(SpawnEnemy());     

            if (Event_Type == EVENT_TYPE.ENEMY_SPECIAL_DEAD)
                ChangeToBrickWall();
        }
    }

    //void Update()
    //{
    //    if (Input.GetKeyDown(KeyCode.Alpha1))
    //    {
    //        // StartCoroutine(SlowMotionExplosion());

    //        FreezingEnemyItemPickup(10.0f);

    //        // StartCoroutine(StartSpawnEnemy());

    //    }

    //    if (Input.GetKeyDown(KeyCode.Alpha2))
    //    {
    //        //StartCoroutine(StartSpawnEnemy());
    //        ExplosionNuCleItemPickup();
    //       // Time.timeScale = 0;
    //    }


    //    if (Input.GetKeyDown(KeyCode.Alpha3))
    //    {
    //        //StartCoroutine(StartSpawnEnemy());
    //       // Time.timeScale = 1;
    //    }
    //}
}
