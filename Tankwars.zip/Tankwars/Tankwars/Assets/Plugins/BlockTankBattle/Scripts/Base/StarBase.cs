﻿using UnityEngine;
using System.Collections;

public class StarBase : MonoBehaviour {

    public GameObject explosionPrefabsFX;

    public Sprite spriteStar;
    public Sprite spriteSkull;
    public GameObject starEffect;

    private SpriteRenderer spriteRender;
    private BaseController ownBase;

    void Awake()
    {
        ownBase = GetComponentInParent<BaseController>();
        spriteRender = GetComponent<SpriteRenderer>();
    }

    //--METHOD CALL WHEN BASE HAVE BEEN DESTROYED--//
    public void CallDestroyBase()
    {
        SmartPool.Spawn(explosionPrefabsFX, transform.position, Quaternion.identity);
        ownBase.DestroyBase();
        ownBase.ExplosionBase();
        spriteRender.sprite = spriteSkull;
        starEffect.SetActive(false);
        GetComponent<BoxCollider2D>().enabled = false;
    }

    //--METHOD RESET--//
    public void Reset()
    {
        starEffect.SetActive(true);
        GetComponent<BoxCollider2D>().enabled = true;
        spriteRender.sprite = spriteStar;
    }
}
