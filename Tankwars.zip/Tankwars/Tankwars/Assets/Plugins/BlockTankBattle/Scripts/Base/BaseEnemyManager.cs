﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

public class BaseEnemyManager : MonoBehaviour,IListener {

    public static BaseEnemyManager Instance
    {
        get { return instance; }
        set { }
    }

    private static BaseEnemyManager instance = null;

    private List<BaseEnemy> baseEnemyList = new List<BaseEnemy>();

    void Awake()
    {
        //If no instance exists, then assign this instance
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject); //Prevent object from being destroyed on scene exit
        }
        else //Instance already exists, so destroy this one. This should be a singleton object
            DestroyImmediate(this);
    }

    void Start()
    {
        StateManager.Instance.OnStateGameStart += FindBaseEnemys;
    }

    //--METHOD SEARCH BASE ENEMY AND CACHING--//
    void FindBaseEnemys()
    {
        baseEnemyList.Clear();

        var arrayObjBase = FindObjectsOfType<BaseEnemy>();

        foreach (BaseEnemy _base in arrayObjBase)
            baseEnemyList.Add(_base);

        //print(baseEnemyList.Count);
    }

    //--METHOD CALL WITH SKILL ITEM EFFECT TO ALL ENEMY--//
    /// <param name="timeAlive"> Time for item effect by time </param>
    public void BaseCallActiveSkill(TypeItems typeItem,float timeAlive = 0.0f)
    {
        switch(typeItem)
        {
            case TypeItems.Nucle:
                foreach (BaseEnemy _base in baseEnemyList)
                    _base.ExplosionNuCleItemPickup();
                break;
            case TypeItems.Freezing:
                foreach (BaseEnemy _base in baseEnemyList)
                    _base.FreezingEnemyItemPickup(timeAlive);
                break;
        }
    }

    public void OnEvent(EVENT_TYPE Event_Type, Component Sender, object Param = null)
    {
        ((IListener)instance).OnEvent(Event_Type, Sender, Param);
    }
}
