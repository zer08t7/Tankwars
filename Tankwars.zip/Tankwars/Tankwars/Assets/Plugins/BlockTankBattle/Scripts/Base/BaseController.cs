﻿using UnityEngine;
using System.Collections;
using System;

//--------CLASS CONTROL BASE--------------//
public class BaseController : MonoBehaviour, IListener
{
    public bool isBaseDead { get { return isDead; } }
    public GameObject brickWalls;
    public StarBase star;

    public GameObject spawnPoints;
    public GameObject FX_Spawn;
    public AudioSource audioSourceShieldBreak;


    protected bool isDead;                                              // Check base have been destroyed or not

    public virtual void Awake()
    {
        StateManager.Instance.OnStageGameEnd += Reset;
    }

    protected virtual void OnDisable()
    {
        StateManager.Instance.OnStageGameEnd -= Reset;
    }

    //--METHOD CALL OUTSIDE CLASS TO COMMAND CHANE BLOCK BASE TO BRICK BASE--//
    public void ChangeToBlockWall()
    {
        StartCoroutine(ChangeSpriteEffect());
    }

    //--METHOD CALL OUTSIDE CALSS TO COMMAND CHANGE BRICK BASE TO BLOCK BASE--//
    public void ChangeToBrickWall()
    {
        SoundManager.Instance.PlaySound(audioSourceShieldBreak);
        StartCoroutine(ActiveBrickEffect());
    }

    // Method make effect when change wall brick to block
    IEnumerator ChangeSpriteEffect()
    {
        var listBlock = brickWalls.GetComponentsInChildren<Block>(true);

        foreach (Block block in listBlock)
        {
            block.gameObject.layer = 9;                                                    // Set layer to bound
            block.gameObject.SetActive(true);
            block.ChangeSprite(1);
            yield return new WaitForSeconds(0.025f);
        }
    }

    // Method make effect when change wall block to brick
    IEnumerator ActiveBrickEffect()
    {
        var listBlock = brickWalls.GetComponentsInChildren<Block>(true);

        bool active = false;

        for (int i = 0; i < 9; i++)
        {
            foreach (Block block in listBlock)
            {
                if (!active)
                    block.ChangeSprite(0);
                else
                    block.ChangeSprite(1);
            }

            active = !active;
            yield return new WaitForSeconds(0.1f);
        }

        foreach (Block block in listBlock)
            block.gameObject.layer = 8;
    }

    // Method reset base when restart game
    // Method need overrite to make different behaviour between base player and base enemy
    public virtual void Reset()
    {
        isDead = false;
        star.Reset();
    }

    //--METHOD SET WALL BASE TO BLOCK--//
    protected void SetBlockBase()
    {
        var listBlock = brickWalls.GetComponentsInChildren<Block>(true);

        foreach (Block block in listBlock)
        {
            block.gameObject.layer = 9;
            block.gameObject.SetActive(true);

            block.ChangeSprite(1);
        }
    }

    public void ExplosionBase()
    {
        var listBlock = brickWalls.GetComponentsInChildren<Block>();
        foreach (Block block in listBlock)
        {
            block.Explosion();
        }
    }

    // Method call destroy base
    public virtual void DestroyBase() { }

    public virtual void OnEvent(EVENT_TYPE Event_Type, Component Sender, object Param = null) { }
}
