﻿using UnityEngine;
using System.Collections;

public class BasePlayer : BaseController {

    public TankPlayer player;
    public int int_base_health = 3;
    public int max_base_health = 5;
    public ParticleSystem FX_ShieldActive;
    public ScoreUI hearthUI;

    public int current_base_health
    {
        get { return _current_base_health; }
        set
        {
            if(value <= max_base_health & value >= 0 )
                hearthUI.AddSccore(value - _current_base_health);

            _current_base_health = Mathf.Clamp(value, 0, max_base_health);

            if (value < 0)
                EventManager.Instance.PostNotification(EVENT_TYPE.GAME_OVER, this);
        }
    }

    private int _current_base_health;

    public override void Awake()
    {
        base.Awake();
        StateManager.Instance.OnStateGameStart += Inital;
        _current_base_health = int_base_health;
    }

    void Start()
    {
        EventManager.Instance.AddListener(EVENT_TYPE.PLAYER_DEAD, this);
    }

    //--METHOD SPAWN PLAYER WHEN ENTER LEVEL GAMEPLAY--//
    void Inital()
    {
        hearthUI.Inital(_current_base_health);
        StartCoroutine(WaitSpawnPlayer());
    }

    //--METHOD COROUNTINE SAPWN PLAYER--//
    IEnumerator WaitSpawnPlayer()
    {
        SmartPool.Spawn(FX_Spawn, spawnPoints.transform.position, Quaternion.identity);
        yield return new WaitForSeconds(1.0f);

        if (!isDead)
        {
            player.ActiveShield(0.5f);
            player.transform.position = spawnPoints.transform.position;
            player.gameObject.SetActive(true);
        }
    }

    //--METHOD CALL DESTROY BASE--//
    public override void DestroyBase()
    {
        isDead = true;
        EventManager.Instance.PostNotification(EVENT_TYPE.PLAYER_BASE_DEAD, this);
        EventManager.Instance.PostNotification(EVENT_TYPE.GAME_OVER, this);
    }


    //--METHOD CALL ACTIVE BLOCK FROM ITEM
    public void ActiveBlockWall(float timeAlive)
    {
        if (!isDead)
        {
            FX_ShieldActive.gameObject.SetActive(true);
            FX_ShieldActive.Play();

            StartCoroutine(ActiveBlockWallInTime(timeAlive));
        }
    }

    //--METHOD INPLEMENT--//
    IEnumerator ActiveBlockWallInTime(float timeAlive)
    {
        ChangeToBlockWall();

        yield return new WaitForSeconds(timeAlive);

        ChangeToBrickWall();
    }

    //--OVERRITE METHOD CALL WHEN END GAME--//
    public override void Reset()
    {
        base.Reset();

        ////Reset player
        player.gameObject.SetActive(false);

        // Reset layer
        var listBlock = brickWalls.GetComponentsInChildren<Block>(true);

        foreach (Block block in listBlock)
        {
            block.gameObject.layer = 8;
            block.gameObject.SetActive(true);

            block.ChangeSprite(0);
        }

        if(StateManager.Instance.gameState == GAME_STATE.GameOver)
            current_base_health = int_base_health;
    }

    public override void OnEvent(EVENT_TYPE Event_Type, Component Sender, object Param = null)
    {
        if (current_base_health > 0 && !isDead)
            StartCoroutine(WaitSpawnPlayer());

        current_base_health--;
    }
}
