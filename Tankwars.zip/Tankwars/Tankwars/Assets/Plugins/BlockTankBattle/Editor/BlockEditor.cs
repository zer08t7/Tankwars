﻿using UnityEngine;
using System.Collections;
using UnityEditor;

public enum TypeAdd
{
	AddLeft,
	AddRight,
	AddAbove,
	AddBottom
}

public class BlockEditor : ScriptableWizard {

	public TypeAdd typeAdd;
	public int numberAdd;

	[MenuItem("Edit/Add Block ...")]

	static void CreateWizard(){
		ScriptableWizard.DisplayWizard ("Add Blocks", typeof(BlockEditor), "Add");
	}

	void OnEnable()
	{
		UpdateSelectionHelper ();
	}

	void OnSelectionChange()
	{
		
		UpdateSelectionHelper ();
	}

	void UpdateSelectionHelper(){
		helpString = "";

		if (Selection.objects != null)
			helpString = "Number of objects selected: " + Selection.objects.Length;
	}

	void OnWizardCreate()
	{
		for(int i = 1; i <= numberAdd; i++)
		{
			for (int j = 0;j<Selection.gameObjects.Length;j++) {
				
				Vector3 posObjectSelect = Selection.gameObjects [j].transform.position;
				GameObject objSpawn = null;

				switch(typeAdd) 
				{
				case TypeAdd.AddAbove:			
					objSpawn = (GameObject) Instantiate (Selection.gameObjects [j], new Vector3 (posObjectSelect.x, posObjectSelect.y + GameController.SIZE_OBJECT/2 * i), Quaternion.identity);
					break;
				case TypeAdd.AddBottom:
					objSpawn = (GameObject) Instantiate (Selection.gameObjects [j], new Vector3 (posObjectSelect.x, posObjectSelect.y - GameController.SIZE_OBJECT/2 * i), Quaternion.identity);
					break;
				case TypeAdd.AddLeft:
					objSpawn = (GameObject) Instantiate (Selection.gameObjects [j], new Vector3 (posObjectSelect.x - GameController.SIZE_OBJECT/2 * i, posObjectSelect.y), Quaternion.identity);
					break;
				case TypeAdd.AddRight:
					objSpawn = (GameObject) Instantiate (Selection.gameObjects [j], new Vector3 (posObjectSelect.x + GameController.SIZE_OBJECT/2 * i, posObjectSelect.y), Quaternion.identity);
					break;			
				}

				objSpawn.transform.SetParent (Selection.gameObjects [j].transform.parent);
				objSpawn.name = Selection.gameObjects [j].GetComponent<Block> ().typeBlock.ToString ();
			}


		}
	}
}
