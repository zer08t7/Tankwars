﻿using UnityEngine;
using UnityEditor;
using System;
using System.Text.RegularExpressions;

[CustomPropertyDrawer(typeof(ObjectPrefab))]
public class ObjectPrefabsEditor : PropertyDrawer {

    public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
    {
        return label != GUIContent.none && Screen.width < 360 ? (16f + 18f) : 16f;
    }

    public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
    {
        int oldIndentLevel = EditorGUI.indentLevel;

        //String labelInddexString = Regex.Match(label.text.ToString(), @"\d+").Value;
        //int index;
        //Int32.TryParse(labelInddexString, out index);
        //label = EditorGUI.BeginProperty(position, new GUIContent(index.ToString()), property);

        label = EditorGUI.BeginProperty(position, label, property);

        Rect contentPosition = EditorGUI.PrefixLabel(position, label);

        if (position.height > 16f)
        {
            position.height = 16f;
            EditorGUI.indentLevel += 1;
            contentPosition = EditorGUI.IndentedRect(position);
            contentPosition.y += 18f;
        }

        contentPosition.width *= 0.65f;
        EditorGUI.indentLevel = 0;
        EditorGUIUtility.labelWidth = 40f;
        EditorGUI.PropertyField(contentPosition, property.FindPropertyRelative("prefabObject"), new GUIContent("Prefab"));

        contentPosition.x += contentPosition.width;
        EditorGUIUtility.labelWidth = 50f;
        contentPosition.width /= 2;
        EditorGUI.PropertyField(contentPosition, property.FindPropertyRelative("quantify"), new GUIContent("Quantify"));
        EditorGUI.EndProperty();
        EditorGUI.indentLevel = oldIndentLevel;
    }
}
