﻿using UnityEngine;
using UnityEditor;

public class RemoveChildObject : MonoBehaviour {

    [ContextMenu("Remove Child Object")]
    void RemoveChild()
    {
        while (transform.childCount > 1)
            DestroyImmediate(transform.GetChild(1).gameObject);
    }
}
