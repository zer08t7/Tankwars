﻿using UnityEngine;
using System.Collections;
using UnityEditor;

public class GridWindow : EditorWindow {

    Grid grid;

    public void init()
    {
        grid = FindObjectOfType<Grid>();
    }

    void OnGUI()
    {
        grid.color = EditorGUILayout.ColorField(grid.color, GUILayout.Width(200));
    }

}
