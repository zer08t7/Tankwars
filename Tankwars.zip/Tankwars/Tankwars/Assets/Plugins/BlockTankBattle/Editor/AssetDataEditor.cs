﻿using UnityEngine;
using UnityEditor;
using System;
using System.Collections.Generic;

[CustomEditor(typeof(AssetData))]
public class AssetDataEditor : Editor {

    AssetData mapData;
    private static GUILayoutOption miniButtonWidth = GUILayout.Width(100f);
    private List<Data> listDataBlocksCurrentLevel;

    void OnEnable()
    {
        mapData = (AssetData)target;
    }

    public override void OnInspectorGUI()
    {
        // Level intergers
        EditorGUI.BeginChangeCheck();
        var currentLevel = EditorGUILayout.IntField("Current stage: ", mapData.stage );

        if (EditorGUI.EndChangeCheck())
        {
            Undo.RecordObject(target, "Change value");
            mapData.stage = currentLevel;
        }

        // Buttons
        EditorGUILayout.BeginHorizontal();

        if (GUILayout.Button(new GUIContent("Save data"), EditorStyles.miniButtonLeft,miniButtonWidth))
            mapData.SaveJsonData();

        if (GUILayout.Button(new GUIContent("Delete All"), EditorStyles.miniButtonMid, miniButtonWidth))
        {
            while (mapData.transform.childCount > 3)
                DestroyImmediate(mapData.transform.GetChild(3).gameObject);
        }

        if (GUILayout.Button(new GUIContent("Load data"), EditorStyles.miniButtonRight, miniButtonWidth))
            LoadDataToEditor();

        EditorGUILayout.EndHorizontal();
    }

    void LoadDataToEditor()
    {
        GameObject[] prefabObjects;

        #region Load asset data
        string[] nameTiles = System.IO.Directory.GetFiles(Application.dataPath + "/Prefabs/Tiles/", "*.prefab", System.IO.SearchOption.AllDirectories);
        prefabObjects = new GameObject[nameTiles.Length];

        for (int i = 0; i < nameTiles.Length; i++) {
            nameTiles[i] = nameTiles[i].Replace(Application.dataPath + "/Prefabs/Tiles/", "");
            prefabObjects[i] = AssetDatabase.LoadAssetAtPath("Assets/Prefabs/Tiles/" + nameTiles[i], typeof(GameObject)) as GameObject;
        }
        #endregion

        listDataBlocksCurrentLevel = new List<Data>();
        listDataBlocksCurrentLevel = mapData.LoadDataJsonEdior(mapData.stage);

        GameObject gameObject = null;

        foreach (Data dataMap in listDataBlocksCurrentLevel)
        {
            gameObject = (GameObject)PrefabUtility.InstantiatePrefab(GetGameobjectByType(prefabObjects, dataMap.typeBlock));
            gameObject.transform.position = new Vector3(dataMap.postionX, dataMap.postionY);
            gameObject.transform.SetParent(mapData.transform);
        }
    }

    // Method return gameobject with type block
    GameObject GetGameobjectByType(GameObject[] objectPrefabsMap, TypeBlock typeBlock)
    {
        foreach (GameObject prefab in objectPrefabsMap)
        {
            if (prefab.GetComponent<Block>().typeBlock == typeBlock)
                return prefab;
        }

        return null;
    }
}
