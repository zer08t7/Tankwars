﻿using UnityEngine;
using System.Collections;
using UnityEditor;
using System.IO;

[CustomEditor(typeof(Grid))]
public class GridEditor : Editor
{

    Grid grid;

    private int oldIndex;

    private Vector3 startMouse;
    private Vector3 endMouse;

    private GameObject objInstantite;

    private RaycastHit hit;
    private Ray ray;

    void OnEnable()
    {
        oldIndex = 0;
        grid = (Grid)target;
    }

    [MenuItem("Assets/Create/TileSet")]
    static void CreateTileSet()
    {
        var asset = ScriptableObject.CreateInstance<TileSet>();
        var path = AssetDatabase.GetAssetPath(Selection.activeObject);

        if (string.IsNullOrEmpty(path))
        {
            path = "Asset";
        }
        else if (Path.GetExtension(path) != "")
        {
            path = path.Replace(Path.GetFileName(path), "");
        }
        else
        {
            path += "/";
        }

        var assetPathAndName = AssetDatabase.GenerateUniqueAssetPath(path + "TileSet.asset");
        AssetDatabase.CreateAsset(asset, assetPathAndName);
        AssetDatabase.SaveAssets();
        EditorUtility.FocusProjectWindow();
        Selection.activeObject = asset;
        asset.hideFlags = HideFlags.DontSave;
    }
    public override void OnInspectorGUI()
    {
        //base.OnInspectorGUI();

        // Start pos
        EditorGUILayout.BeginHorizontal();
        EditorGUI.BeginChangeCheck();
        var startPos = EditorGUILayout.Vector3Field("Start postion grid :", grid.startPostion, null);
       
        if (EditorGUI.EndChangeCheck())
        {
            Undo.RecordObject(target, "Grid change");
            grid.startPostion = startPos;
        }
        EditorGUILayout.EndHorizontal();

        // Grid size
        EditorGUI.BeginChangeCheck();
        var gridSize = EditorGUILayout.FloatField("Size grid", grid.gridSize);
        grid.gridSize = gridSize;

        if (EditorGUI.EndChangeCheck())
        {
            Undo.RecordObject(target, "Grid change");
            grid.gridSize = gridSize;
        }

        // Number grid on screen
        EditorGUI.BeginChangeCheck();

        var height = createSlider(" Height", grid.numberGridHeight);
        if (EditorGUI.EndChangeCheck())
        {
            Undo.RecordObject(target, "Grid change");
            grid.numberGridHeight = height;
        }

        EditorGUI.BeginChangeCheck();
        var width = createSlider(" Wildth", grid.numberGridWidth);
        if (EditorGUI.EndChangeCheck())
        {
            Undo.RecordObject(target, "Grid change");
            grid.numberGridWidth = width;
        }


        // Grid window
        if (GUILayout.Button("Open grid Window"))
        {
            GridWindow window = (GridWindow)EditorWindow.GetWindow(typeof(GridWindow));
            window.init();
        }

        // Tile prefabs
        EditorGUI.BeginChangeCheck();
        var newTilePrefab = (Transform)EditorGUILayout.ObjectField("Tile Prefab", grid.tilePrefab, typeof(Transform), false);
        if (EditorGUI.EndChangeCheck())
        {
            Undo.RecordObject(target, "Grid change");
            grid.tilePrefab = newTilePrefab;
        }

        // TileMap
        EditorGUI.BeginChangeCheck();
        var newTileSet = (TileSet)EditorGUILayout.ObjectField("Tile Set", grid.tileSet, typeof(TileSet), false);
        if (EditorGUI.EndChangeCheck())
        {
            Undo.RecordObject(target, "Grid Changed");
            grid.tileSet = newTileSet;         
        }

        //Tile Set
        if (grid.tileSet != null)
        {
            EditorGUI.BeginChangeCheck();
            var names = new string[grid.tileSet.prefabs.Length];
            var values = new int[names.Length];

            for (int i = 0; i < names.Length; i++)
            {
                names[i] = grid.tileSet.prefabs[i] != null ? grid.tileSet.prefabs[i].name : "";
                values[i] = i;
            }

            var index = EditorGUILayout.IntPopup("Select Tile", oldIndex, names, values);

            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(target, "Grid Changed");
                if (oldIndex != index)
                {
                    oldIndex = index;
                    grid.tilePrefab = grid.tileSet.prefabs[index];
                }
            }
        }

        EditorGUI.BeginChangeCheck();

        bool draggable = EditorGUILayout.Toggle("Can move object: ", grid.canMoveObject);
        if (EditorGUI.EndChangeCheck())
        {
            Undo.RecordObject(target, "Grid Changed");
            grid.canMoveObject = draggable;        
        }
    }

    //--------------------------------------------------------------------------------------------------------------------------
    //--INPLEMENT MOUSE EVENT FOR EDIT MAP---//
    void OnSceneGUI()
    {
        int controlId = GUIUtility.GetControlID(FocusType.Passive);
        Event e = Event.current;
        ray = Camera.current.ScreenPointToRay(new Vector3(e.mousePosition.x, -e.mousePosition.y + Camera.current.pixelHeight));
        Vector3 mousePos = ray.origin;

        #region Make first tile when click screen

        if (e.isMouse && e.type == EventType.MouseDown && e.button == 0)
        {
            GUIUtility.hotControl = controlId;
            e.Use();
            GameObject gameObject = null;
            Transform prefab = grid.tilePrefab;
            startMouse = mousePos;

            if (prefab)
            {
                Undo.IncrementCurrentGroup();

                Vector3 aligned = new Vector3(Mathf.Floor((mousePos.x + grid.gridSize/2)  / grid.gridSize)  * grid.gridSize , Mathf.Floor((mousePos.y) / grid.gridSize) * grid.gridSize + grid.gridSize/2, 0.0f);   

                if (!GetTranform(aligned) || grid.canMoveObject)
                    gameObject = (GameObject)PrefabUtility.InstantiatePrefab(prefab.gameObject);
                else
                    return;

                if (!grid.canMoveObject)
                    gameObject.transform.position = aligned;
                else {
                    objInstantite = gameObject;
                    objInstantite.transform.position = new Vector3(mousePos.x, mousePos.y, 0.0f);
                }

                gameObject.AddComponent<Rigidbody>().isKinematic = true;
                gameObject.AddComponent<BoxCollider>().size = new Vector3(grid.gridSize, grid.gridSize, 1.0f);
                gameObject.transform.parent = grid.transform;

                Undo.RegisterCreatedObjectUndo(gameObject, " Create " + gameObject.name);
            }
        }
        #endregion

        #region When hold mose and move mouse. Check object can move

        if (e.isMouse && e.type == EventType.MouseDrag && e.button == 0 && grid.canMoveObject)
        {
            GUIUtility.hotControl = controlId;
            e.Use();

            objInstantite.transform.position = new Vector3(mousePos.x, mousePos.y, 0.0f);
        }
        #endregion

        #region Can drag to make edit map more quickly
        if (e.isMouse && e.type == EventType.MouseUp && e.button == 0 && !grid.canMoveObject)
        {
            GUIUtility.hotControl = controlId;
            e.Use();
            endMouse = mousePos;
            FillAreaGrid(startMouse, endMouse);

            startMouse = Vector3.zero;
            endMouse = Vector3.zero;

            GUIUtility.hotControl = 0;

            if (objInstantite)
                objInstantite = null;
        }
        #endregion

        #region Delete object with left mouse
        if (e.isMouse & (e.type == EventType.MouseDrag || e.type == EventType.MouseDown) && e.button == 1)
        {
            GUIUtility.hotControl = controlId;
            e.Use();

            if (Physics.Raycast(ray, out hit))
                DestroyImmediate(hit.transform.gameObject);
        }
        #endregion
    }

    //--------------------------------------------------------------------------------------------------------------------------
    //--METHOD CREATE SLIDER ON GUI INSPECTOR--//
    private int createSlider(string labelName, int sliderPostion)
    {
        GUILayout.BeginHorizontal();
        GUILayout.Label("Grid" + labelName);
        sliderPostion = EditorGUILayout.IntSlider(sliderPostion, 1, 100, null);
        GUILayout.EndHorizontal();

        return sliderPostion;
    }

    //--------------------------------------------------------------------------------------------------------------------------
    //--METHOD FIND GAME OBJECT FROM POSTION 
    private Transform GetTranform(Vector3 aligned)
    {
        int i = 0;
        while (i < grid.transform.childCount)
        {
            Transform transform = grid.transform.GetChild(i);
            if (transform.position == aligned)
            {
                return transform;
            }

            i++;
        }
        return null;
    }

    //--------------------------------------------------------------------------------------------------------------------------
    //--METHOD FILL ARE USE WHITH DRAG OBJECT FOR QUICKLY EDIT MAP--//
    void FillAreaGrid(Vector3 _StartPosition, Vector3 _EndPosition)
    {
        Vector3 posGridStart = new Vector3(Mathf.Floor((_StartPosition.x + grid.gridSize/2) / grid.gridSize) * grid.gridSize, Mathf.Floor(_StartPosition.y / grid.gridSize) * grid.gridSize + grid.gridSize / 2);
        Vector3 posGridEnd = new Vector3(Mathf.Floor((_EndPosition.x + grid.gridSize/2) / grid.gridSize) * grid.gridSize + grid.gridSize / 2, Mathf.Floor(_EndPosition.y / grid.gridSize) * grid.gridSize + grid.gridSize / 2);

       // Debug.Log(posGridStart.ToString("F2") + " " + posGridEnd.ToString("F2"));

        int numGridX = (int) Mathf.Abs( (posGridStart.x - posGridEnd.x) / (grid.gridSize)) + 1;
        int numGridY = (int)Mathf.Abs((posGridStart.y - posGridEnd.y) / (grid.gridSize)) + 1;

        for(int x=0;x<numGridX;x++)
            for(int y=0;y<numGridY;y++)
            {
                GameObject gameObject;
                Vector3 realWorldPosition = new Vector3(posGridStart.x + x * grid.gridSize * Mathf.Sign(posGridEnd.x - posGridStart.x), posGridStart.y + y * grid.gridSize * Mathf.Sign(posGridEnd.y - posGridStart.y));

                var posScreen = Camera.current.WorldToScreenPoint(realWorldPosition);
                ray = Camera.current.ScreenPointToRay(posScreen);

                if (!Physics.Raycast(ray, out hit))
                {
                    gameObject = (GameObject)PrefabUtility.InstantiatePrefab(grid.tilePrefab.gameObject);
                    gameObject.transform.position = realWorldPosition;
                    gameObject.transform.parent = grid.transform;
                    gameObject.AddComponent<Rigidbody>().isKinematic = true;
                    gameObject.AddComponent<BoxCollider>().size = new Vector3(grid.gridSize, grid.gridSize, 1.0f);

                    Undo.RegisterCreatedObjectUndo(gameObject, " Create " + gameObject.name);
                }
            }
    }
}
