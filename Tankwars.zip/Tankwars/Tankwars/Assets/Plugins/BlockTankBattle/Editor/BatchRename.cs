﻿using UnityEngine;
using System.Collections;
using UnityEditor;

public class BatchRename : ScriptableWizard {

	public string BaseName = "MyObject_";

	public int StartNumber = 0;

	public int IncreaseNumber = 1;

	[MenuItem("Edit/Batch Rename ...")]

	static void CreateWizard(){
		ScriptableWizard.DisplayWizard ("Batch Rename", typeof(BatchRename), "Rename");
	}

	void OnEnable()
	{
		UpdateSelectionHelper ();
	}

	void OnSlectionChange()
	{
		UpdateSelectionHelper ();
	}

	void UpdateSelectionHelper(){
		helpString = "";

		if (Selection.objects != null)
			helpString = "Number of objects slected: " + Selection.objects.Length;
	}

	void OnWizardCreate(){
		
		if (Selection.objects == null)
			return;

		int PostFix = StartNumber;

        if (Selection.objects.Length > 1)
        {
            for (int i = Selection.objects.Length - 1; i >= 0; i--)
            {
                if (PostFix > 10)
                    Selection.objects[i].name = BaseName + PostFix;
                else
                    Selection.objects[i].name = BaseName + "0" + PostFix;
                PostFix += IncreaseNumber;
            }
        }
        else
        {
            var parentObj = (GameObject) Selection.objects[0];
            for(int i=0;i<parentObj.transform.childCount;i++)
            {
                if (i > 8)
                    parentObj.transform.GetChild(i).name = BaseName + (i + 1).ToString();
                else
                    parentObj.transform.GetChild(i).name = BaseName + "0" + (i + 1).ToString();
            }
        }
	}
}
