﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TankController : MonoBehaviour {
	public GameObject Tank;
	public Bulletcontrol Bcon;
	public GameObject Bullet;
	public int turn; // 0:up 1:right 2:left 3:down
	private int bullettimer ;
	private float Speed = 3;
	float x;
	float y;
	public int blood;
	public Heartcontrol hc;
	private Vector3 Player1posi = new Vector3 (-3.32f,-1.36f,0);
	private Vector3 Player2posi = new Vector3 (0.17f,3.24f,0);
	// Use this for initialization

	Quaternion turnup = Quaternion.Euler (0,0,0);
	Quaternion turndown = Quaternion.Euler (0,0,180);	
	Quaternion turnleft = Quaternion.Euler (0,0,90);
	Quaternion turnright = Quaternion.Euler (0,0,-90);	

	void Start () 
	{
		
	}
	
	// Update is called once per frame
	void Update () 
	{
		if (gameObject.name == "Player") 
		{
			x = Input.GetAxis ("Horizontal");
			y = Input.GetAxis ("Vertical");
		}

		else 
		{
			x = Input.GetAxis ("Horizontal2");
			y = Input.GetAxis ("Vertical2");
		}
		if (x != 0) 
		{
			Tank.transform.position += new Vector3 (x*Time.deltaTime*Speed,0, 0);
			if (x > 0) 
			{
				Tank.transform.rotation = turnright;
				turn = 1;

			} else {
				Tank.transform.rotation = turnleft;
				turn = 2;
			}
		}

		else if (y != 0) 
		{
			Tank.transform.position += new Vector3 (0,y*Time.deltaTime*Speed, 0);
			if (y > 0) 
			{
				Tank.transform.rotation = turnup;
				turn = 0;
			} else 
			{
				Tank.transform.rotation = turndown;
				turn = 3;
		    }
		}
		if(Input.GetKey("space"))
		{
			if (gameObject.name == "Player") 
			{
				GameObject Bullettemp = Instantiate (Bcon.gameObject);
				Bullettemp.transform.position = Bcon.transform.position;
				Bullettemp.transform.localScale = Bcon.transform.localScale * 2;
				Bullettemp.GetComponent<Bulletcontrol> ().Turntype = turn;
				Debug.Log (turn);
				Bullettemp.gameObject.SetActive (true);
			}
		}
		if(Input.GetMouseButtonDown(0))
		{
			if (gameObject.name == "Player2") 
			{
				GameObject Bullettemp = Instantiate (Bcon.gameObject);
				Bullettemp.transform.position = Bcon.transform.position;
				Bullettemp.transform.localScale = Bcon.transform.localScale * 2;
				Bullettemp.GetComponent<Bulletcontrol> ().Turntype = turn;
				Debug.Log (turn);
				Bullettemp.gameObject.SetActive (true);
			}
		}
		//Tank.transform.rotation
	
	}
	void OnTriggerEnter2D(Collider2D coll) 
	{
		if (coll.tag == "Bush")
		{
			
			Speed = 0.5f;
		}
		if (coll.tag == "water")
		{
			Speed = 0.5f;
		}
	}

	void OnTriggerExit2D(Collider2D coll)
	{
		if (coll.tag == "Bush") 
		{
			Speed = 3;
		}
		if (coll.tag == "water") 
		{
			Speed = 3;
		}
	}
	public void gethit()
	{
		blood = blood - 1;
		hc.HCcontrol (blood);
	}
	public void respawn()
	{
		blood = 3;
		hc.HCcontrol (blood);
		if (Tank.tag  == "Player")
		{
			if (gameObject.name == "Player") 
			{
				Tank.transform.position = new Vector3 (-3.32f, -1.36f, 0);
				Debug.Log (Player1posi);
			}
			else
			{
				Tank.transform.position = Player2posi;
			}
		}

	}
}
