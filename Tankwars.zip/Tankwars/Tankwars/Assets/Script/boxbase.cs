﻿	using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class boxbase : MonoBehaviour {

	public int hp = 5;
	// Use this for initialization
	void Start () {
		hp = 5;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
