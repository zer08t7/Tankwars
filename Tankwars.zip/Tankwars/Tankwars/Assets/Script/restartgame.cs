﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class restartgame : MonoBehaviour {

	// Use this for initialization
	void Start () {
		iTween.MoveTo(gameObject,iTween.Hash("time",5,"oncomplete","turnback", "oncompletetarget", gameObject));
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	public void turnback() 
	{
		Debug.Log ("start");

		Application.LoadLevel ("Startscene");
	}
}
