﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bulletcontrol : MonoBehaviour 
{
	// Use this for initialization
	public int Turntype = 0;
	public GameObject TankOB;
	Quaternion turnup = Quaternion.Euler (0,0,0);
	Quaternion turndown = Quaternion.Euler (0,0,180);	
	Quaternion turnleft = Quaternion.Euler (0,0,90);
	Quaternion turnright = Quaternion.Euler (0,0,-90);
	public GameBtnControl lose1;
	void Start () 
	{
		
	}
	
	// Update is called once per frame
	void Update () 
	{
		if (Turntype == 0) 
		{
			transform.rotation = turnup;
			transform.position = transform.position + new Vector3 (0,1,0)*Time.deltaTime*3;
		}
		if (Turntype == 3) 
		{
			transform.rotation = turndown;
			transform.position = transform.position + new Vector3 (0,-1,0)*Time.deltaTime*3;
		}
		if (Turntype == 1) 
		{
			transform.rotation = turnright;
			transform.position = transform.position + new Vector3 (1,0,0)*Time.deltaTime*3;
		}
		if (Turntype == 2) 
		{
			transform.rotation = turnleft;
			transform.position = transform.position + new Vector3 (-1,0,0)*Time.deltaTime*3;
		}
	}
	void OnCollisionEnter2D(Collision2D coll) 
	{
		if (coll.gameObject.tag == "base")
		{
			int hp = coll.gameObject.GetComponent<boxbase> ().hp;
			hp = hp - 1;
			if (hp <= 0) 
			{
				GameObject.Destroy (coll.gameObject);
				if (gameObject.tag == "base")
				{
					Debug.Log ("You lose Player2win");

					Application.LoadLevel ("scene2");
				}
				else 
				{
					Debug.Log ("You lose Player1win");

					Application.LoadLevel ("scene3");
				}
			} 
			else 
			{
				coll.gameObject.GetComponent<boxbase> ().hp = hp;
			}
		}
		if (coll.gameObject != TankOB)
		{
			GameObject.Destroy (gameObject);
			if(coll.gameObject.tag == "Player")
			{
				coll.gameObject.GetComponent<TankController> ().gethit ();
			}
		}

		if (coll.gameObject.tag == "Wood") 
		{
			GameObject.Destroy (gameObject);
		}
		if (coll.gameObject.tag == "Stone") 
		{
			GameObject.Destroy (gameObject);
		}
		if (coll.gameObject.tag == "Wood")
		{
			int hp = coll.gameObject.GetComponent<boxbase> ().hp;
			hp = hp - 3;
			if (hp <= 0) 
			{
				GameObject.Destroy (coll.gameObject);
			} 
			else 
			{
				coll.gameObject.GetComponent<boxbase> ().hp = hp;
			}
		}
		if (coll.gameObject.tag == "Stone") 
		{
			int hp = coll.gameObject.GetComponent<boxbase> ().hp;
			hp = hp - 2;
			if (hp <= 0) 
			{
				GameObject.Destroy (coll.gameObject);
			} 
			else 
			{
				coll.gameObject.GetComponent<boxbase> ().hp = hp;
			}
		}
     }
}